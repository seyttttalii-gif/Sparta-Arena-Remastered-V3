# SPARTA ARENA REMASTERED

Godot 4 / Windows single-player remaster prototype for the Sparta Arena V57 project.

## Open the project
Open `project.godot` from this folder in Godot 4.x. Use the `Windows Desktop` export preset to export a Windows build.

## What this milestone includes
- Character, map, mode, shop, potion, achievement and save systems.
- 13-second intro with six random camera variants and Skip.
- Separate audio, graphics/performance, gameplay and controls pages.
- Clickable world-conquest strategy chart: 72 cities / 6 continents, contiguous army movement, troops/morale, dialogue, diplomacy, surrender, tribute and siege battles.
- Clickable sea chart: ports/islands, ship health, supplies, route rewards, storms, pirate encounters, fishing bait choices and rod upgrades.
- Menu/credits accents; credits list SEYİT ALİ as founder/game designer.
- Medium is used as the one-time upgraded default profile; Low/Medium/High graphics quality and 30/60/120 FPS choices are available.

## Important limits
This remains an in-development prototype, not a complete Bannerlord-scale game. The source V57 package is preserved under `legacy_v57/`. Current world/sea screens are interactive 2D charts connected to 3D combat, not fully simulated 3D continents or physics-based ship battles. Current warriors are stylized procedural low-poly-like models, because the original V57 archive does not include professional rigged 3D models or animation rigs. The full online multiplayer server, bespoke levels, organic 3D models and final animation/VFX work are not complete.

## Validation note
Run Godot import, headless launch and Windows export via GitHub Actions, then test the exported EXE. Static package checks do not replace runtime and gameplay testing.
