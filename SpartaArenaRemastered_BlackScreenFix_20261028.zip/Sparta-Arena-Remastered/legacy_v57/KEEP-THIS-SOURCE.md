# Legacy source preservation

These files were copied from the user-supplied `SPARTA_ARENA_V57_ANDROID_READY(3).zip` with only Python `__pycache__`/`.pyc` files excluded. Do not delete this folder during migration. `app/main.py` remains a reference source; it has not been mechanically converted to Godot.
