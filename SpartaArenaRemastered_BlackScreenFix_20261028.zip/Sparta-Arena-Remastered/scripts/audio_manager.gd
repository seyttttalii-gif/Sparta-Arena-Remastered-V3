extends Node

# Audio resources are loaded at runtime, not with preload().
# This avoids an import-order problem where a fresh Godot editor scan compiles
# this autoload before WAV import metadata exists, which can abort startup.
var _intro_score: AudioStreamWAV
var _menu_ambience: AudioStreamWAV
var _ui_tap: AudioStreamWAV
var _muted_impact: AudioStreamWAV

var music_volume: float = 0.58
var sfx_volume: float = 0.34
var sfx_enabled: bool = true
var _music_player: AudioStreamPlayer
var _sfx_players: Array[AudioStreamPlayer] = []
var _next_sfx_player: int = 0

func _ready() -> void:
    _intro_score = _load_audio("res://assets/audio/intro_score.wav")
    _menu_ambience = _load_audio("res://assets/audio/menu_ambience.wav")
    _ui_tap = _load_audio("res://assets/audio/ui_soft_tap.wav")
    _muted_impact = _load_audio("res://assets/audio/muted_metal_impact.wav")

    _music_player = AudioStreamPlayer.new()
    _music_player.name = "MusicPlayer"
    add_child(_music_player)
    _music_player.finished.connect(_on_music_finished)

    for i in range(4):
        var player := AudioStreamPlayer.new()
        player.name = "SfxPlayer%d" % i
        add_child(player)
        _sfx_players.append(player)

func _load_audio(path: String) -> AudioStreamWAV:
    var resource: Resource = load(path)
    if resource is AudioStreamWAV:
        return resource as AudioStreamWAV
    push_warning("Ses dosyasi yuklenemedi; oyun sessiz devam edecek: " + path)
    return null

func set_music_volume(value: float) -> void:
    music_volume = clampf(value, 0.0, 1.0)
    if is_instance_valid(_music_player):
        _music_player.volume_db = linear_to_db(maxf(0.001, music_volume))

func set_sfx_volume(value: float) -> void:
    sfx_volume = clampf(value, 0.0, 1.0)

func set_sfx_enabled(enabled: bool) -> void:
    sfx_enabled = enabled

func play_intro_score() -> void:
    if _intro_score != null:
        _start_music(_intro_score, false)

func play_menu_ambience() -> void:
    if _menu_ambience != null:
        _start_music(_menu_ambience, true)

func stop_music() -> void:
    if is_instance_valid(_music_player):
        _music_player.stop()

func play_ui() -> void:
    _play_sfx(_ui_tap, -2.5)

func play_muted_impact() -> void:
    _play_sfx(_muted_impact, -5.0)

func _start_music(source: AudioStreamWAV, should_loop: bool) -> void:
    if source == null or not is_instance_valid(_music_player):
        return
    _music_player.stop()
    var copied := source.duplicate() as AudioStreamWAV
    if copied == null:
        return
    if should_loop:
        copied.loop_mode = AudioStreamWAV.LOOP_FORWARD
    _music_player.stream = copied
    _music_player.volume_db = linear_to_db(maxf(0.001, music_volume))
    _music_player.play()

func _play_sfx(source: AudioStreamWAV, trim_db: float) -> void:
    if source == null or not sfx_enabled or sfx_volume <= 0.001 or _sfx_players.is_empty():
        return
    var player := _sfx_players[_next_sfx_player]
    _next_sfx_player = (_next_sfx_player + 1) % _sfx_players.size()
    player.stream = source
    # Both assets are intentionally low-amplitude, with no harsh high-frequency transient.
    player.volume_db = linear_to_db(maxf(0.001, sfx_volume * 0.55)) + trim_db
    player.play()

func _on_music_finished() -> void:
    # The intro score is one-shot; menu ambience is looped by its WAV resource setting.
    pass
