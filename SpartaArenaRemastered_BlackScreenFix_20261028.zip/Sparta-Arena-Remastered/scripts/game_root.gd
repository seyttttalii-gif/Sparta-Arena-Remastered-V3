extends Node3D

# SPARTA ARENA REMASTERED
# Broad first-pass migration of V57's catalog and progression into Godot.
# Temporary procedural 3D art is used because the V57 ZIP contains no 3D model assets.

const INTRO_DURATION: float = 13.0
const GOLD := Color(0.82, 0.62, 0.29)
const PALE_GOLD := Color(0.96, 0.82, 0.55)
const TEXT_LIGHT := Color(0.89, 0.89, 0.86)
const MUTED_TEXT := Color(0.68, 0.70, 0.72)
const CONFIG_PATH := "user://sparta_remastered.cfg"
const SAVE_PATH := "user://sparta_remastered_save.json"
const CHARACTER_FILE := "res://data/characters.json"
const MAP_FILE := "res://data/maps.json"
const MODE_FILE := "res://data/game_modes.json"
const CITY_FILE := "res://data/world_city_pools.json"
const ITEMS_PER_PAGE := 5

var _characters: Array = []
var _maps: Array = []
var _modes: Array = []
var _city_pools: Array = []
var _save_data: Dictionary = {}
var _config := ConfigFile.new()
var _awaiting_rebind: String = ""

var _camera: Camera3D
var _world_environment: WorldEnvironment
var _arena_floor: MeshInstance3D
var _map_decor: Node3D
var _screen_mode: String = "boot"
var _intro_time: float = 0.0
var _intro_seen: bool = false
var _music_volume: float = 0.44
var _sfx_volume: float = 0.28
var _sfx_enabled: bool = true
var _difficulty: String = "ORTA"
var _intro_variant: int = 0
var _graphics_quality: String = "ORTA"
var _graphics_fps: int = 60
var _animation_clock: float = 0.0
var _attack_swing_time: float = 0.0

# Playable strategy / sea chart state.
var _strategy_layer: Control
var _strategy_canvas: Control
var _strategy_title: Label
var _strategy_subtitle: Label
var _strategy_info: Label
var _strategy_actions: VBoxContainer
var _strategy_type: String = "world"
var _strategy_selected_index: int = 0
var _strategy_notice: String = ""
var _strategy_dialogue_open: bool = false
var _sea_encounter_pending: bool = false
var _conquest_battle_target: String = ""
var _sea_battle_active: bool = false

var _ui_layer: CanvasLayer
var _intro_layer: Control
var _menu_layer: Control
var _intro_title: Label
var _intro_subtitle: Label
var _intro_progress: ProgressBar
var _skip_button: Button
var _menu_panel: PanelContainer
var _page_title: Label
var _page_subtitle: Label
var _page_body: Label
var _menu_buttons: VBoxContainer
var _menu_scroll: ScrollContainer
var _dim_layer: ColorRect
var _menu_warriors: Array[Node3D] = []

# Compact in-combat HUD: keeps the 3D arena visible instead of the full menu panel.
var _combat_hud_layer: Control
var _combat_hud_info: Label
var _combat_health_bar: ProgressBar
var _combat_status_label: Label
var _combat_hud_message: String = "WASD hareket • Space/sol tık saldırı • H iksir • ESC duraklat"

var _player: Node3D
var _enemies: Array[Dictionary] = []
var _combat_health: float = 100.0
var _combat_max_health: float = 100.0
var _attack_was_down: bool = false
var _potion_was_down: bool = false
var _attack_cooldown: float = 0.0
var _enemy_hit_cooldown: float = 0.0
var _wave_delay: float = 0.0
var _wave_transition_pending: bool = false
var _combat_ended: bool = false
var _wave: int = 0
var _kills_this_run: int = 0
var _mode_time_left: float = 0.0
var _hill_progress: float = 0.0
var _caravan_health: float = 100.0
var _potato_holder: String = "player"
var _hud_tick: float = 0.0
var _selected_mode_key: String = "classic"
var _last_result_text: String = ""

func _ready() -> void:
    print("[SPARTA BOOT] Baslangic")
    randomize()
    DisplayServer.window_set_title("SPARTA ARENA REMASTERED")
    print("[SPARTA BOOT] Veri kataloglari yukleniyor")
    _load_catalogs()
    _load_preferences()
    _load_save_data()
    print("[SPARTA BOOT] 3D arena olusturuluyor")
    _build_3d_world()
    print("[SPARTA BOOT] Arayuz olusturuluyor")
    _build_ui()
    _apply_graphics_settings()
    _apply_map_theme(int(_save_data.get("selected_map", 0)))
    # Her baslatmada 6 sinematik varyanttan biri rastgele secilir.
    _begin_intro()
    print("[SPARTA BOOT] Baslangic tamamlandi")

func _process(delta: float) -> void:
    if _screen_mode == "intro":
        _intro_time += delta
        _update_intro_camera()
        if is_instance_valid(_intro_progress):
            _intro_progress.value = clampf(_intro_time / INTRO_DURATION * 100.0, 0.0, 100.0)
        if is_instance_valid(_intro_title):
            _intro_title.modulate.a = clampf(_intro_time / 1.4, 0.0, 1.0)
            _intro_subtitle.modulate.a = clampf((_intro_time - 0.7) / 1.4, 0.0, 1.0)
        if _intro_time >= INTRO_DURATION:
            _finish_intro()
    elif _screen_mode == "menu":
        _update_menu_camera(delta)
    elif _screen_mode == "combat":
        _update_combat(delta)

func _unhandled_input(event: InputEvent) -> void:
    if _awaiting_rebind != "" and event is InputEventKey and event.pressed and not event.echo:
        var key_event := event as InputEventKey
        if key_event.keycode == KEY_ESCAPE:
            _awaiting_rebind = ""
            _show_settings()
            get_viewport().set_input_as_handled()
            return
        var code := int(key_event.physical_keycode if key_event.physical_keycode != 0 else key_event.keycode)
        var binds: Dictionary = _save_data.get("keybinds", {})
        binds[_awaiting_rebind] = code
        _save_data["keybinds"] = binds
        _awaiting_rebind = ""
        _save_game()
        _show_settings()
        get_viewport().set_input_as_handled()
        return
    if event is InputEventKey and event.pressed and not event.echo and event.keycode == KEY_ESCAPE:
        if _screen_mode == "combat":
            _show_pause_menu()
            get_viewport().set_input_as_handled()
        elif _screen_mode == "paused":
            _resume_combat()
            get_viewport().set_input_as_handled()
        elif _screen_mode == "strategy_world" or _screen_mode == "strategy_sea":
            _show_menu()
            get_viewport().set_input_as_handled()

func _load_catalogs() -> void:
    _characters = _read_json_array(CHARACTER_FILE)
    _maps = _read_json_array(MAP_FILE)
    _modes = _read_json_array(MODE_FILE)
    _city_pools = _read_json_array(CITY_FILE)
    if _characters.is_empty():
        _characters = [{"name":"Spartalı", "speed":7.0, "attack":8, "defense":5, "hp_bonus":0, "cape":[0.7,0.15,0.1], "armor":[0.6,0.4,0.2]}]
    if _maps.is_empty():
        _maps = [{"name":"Antik Roma Arenası", "floor":[0.36,0.29,0.20], "sky":[0.012,0.018,0.032], "accent":[0.76,0.50,0.20]}]
    if _modes.is_empty():
        _modes = [{"key":"classic", "name":"Klasik Arena", "description":"Dalga tabanlı arena mücadelesi."}]

func _read_json_array(path: String) -> Array:
    if not FileAccess.file_exists(path):
        push_warning("Veri dosyası bulunamadı: " + path)
        return []
    var parsed = JSON.parse_string(FileAccess.get_file_as_string(path))
    if parsed is Array:
        return parsed
    push_warning("JSON listesi okunamadı: " + path)
    return []

func _default_save_data() -> Dictionary:
    return {
        "gold": 500,
        "classic_wins": 0,
        "total_games": 0,
        "total_kills": 0,
        "selected_character": 1,
        "selected_map": 0,
        "classic_round_limit": 30,
        "potions": 2,
        "full_potions": 0,
        "damage_bonus": 0,
        "defense_bonus": 0,
        "sword_level": 0,
        "armor_level": 0,
        "captured_cities": [],
        "conquest_continent": 0,
        "conquest_current_city": "Sivas",
        "conquest_selected_city": "Kuzey Kalesi",
        "conquest_morale": 80,
        "conquest_supplies": 100,
        "conquest_days": 1,
        "conquest_reputation": 0,
        "conquest_relations": {"Sparta":0,"Roma":0,"Hun":0,"Pers":0,"Kuzey Krallığı":0,"Çöl Sultanlığı":0},
        "troops": 20,
        "daily_reward_date": "",
        "achievements": {},
        "settings": {"music_volume":0.44, "sfx_volume":0.28, "sfx_enabled":true, "difficulty":"ORTA", "fullscreen":false, "control_mode":"keyboard_mouse", "graphics_quality":"ORTA", "fps_limit":60},
        "keybinds": {"move_forward":KEY_W, "move_back":KEY_S, "move_left":KEY_A, "move_right":KEY_D, "attack":KEY_SPACE, "potion":KEY_H},
        "sea": {"gold":300, "ships":0, "rod_level":1, "fish_caught":0, "islands_discovered":0, "map_fragments":0, "relics":0, "current_location":0, "selected_location":1, "visited_locations":[0], "ship_health":100, "pirate_defeats":0, "supplies":100, "sea_days":1},
        "dev": {"unlock_all":false, "infinite_gold":false, "test_mode":false},
        "mode_stats": {"endless_kills":0, "bosses_defeated":0, "hill_wins":0, "sea_runs":0}
    }

func _load_save_data() -> void:
    _save_data = _default_save_data()
    if FileAccess.file_exists(SAVE_PATH):
        var parsed = JSON.parse_string(FileAccess.get_file_as_string(SAVE_PATH))
        if parsed is Dictionary:
            for key in parsed.keys():
                if _save_data.get(key) is Dictionary and parsed[key] is Dictionary:
                    var destination: Dictionary = _save_data[key]
                    for subkey in parsed[key].keys():
                        destination[subkey] = parsed[key][subkey]
                    _save_data[key] = destination
                else:
                    _save_data[key] = parsed[key]
    _save_data["selected_character"] = clampi(int(_save_data.get("selected_character", 1)), 0, _characters.size() - 1)
    _save_data["selected_map"] = clampi(int(_save_data.get("selected_map", 0)), 0, _maps.size() - 1)
    var settings: Dictionary = _save_data.get("settings", {})
    _music_volume = clampf(float(settings.get("music_volume", 0.44)), 0.0, 1.0)
    _sfx_volume = clampf(float(settings.get("sfx_volume", 0.28)), 0.0, 1.0)
    _sfx_enabled = bool(settings.get("sfx_enabled", true))
    _difficulty = str(settings.get("difficulty", "ORTA"))
    var sea_defaults: Dictionary = _save_data.get("sea", {})
    sea_defaults["current_location"] = clampi(int(sea_defaults.get("current_location", 0)), 0, 7)
    sea_defaults["selected_location"] = clampi(int(sea_defaults.get("selected_location", 1)), 0, 7)
    if not (sea_defaults.get("visited_locations", [0]) is Array):
        sea_defaults["visited_locations"] = [0]
    _save_data["sea"] = sea_defaults
    # One-time upgrade: the previous prototype defaulted to Low, which hid most character details.
    # Keep a user-selected profile after this marker has been saved.
    if not bool(settings.get("graphics_profile_migrated", false)):
        settings["graphics_quality"] = "ORTA"
        settings["fps_limit"] = 60
        settings["graphics_profile_migrated"] = true
        _save_data["settings"] = settings
    _graphics_quality = str(settings.get("graphics_quality", "ORTA"))
    if not (_graphics_quality in ["DÜŞÜK", "ORTA", "YÜKSEK"]):
        _graphics_quality = "ORTA"
    _graphics_fps = int(settings.get("fps_limit", 60))
    if not (_graphics_fps in [30, 60, 120]):
        _graphics_fps = 60
    if bool(settings.get("fullscreen", false)):
        DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_FULLSCREEN)
    AudioManager.set_music_volume(_music_volume)
    AudioManager.set_sfx_volume(_sfx_volume)
    AudioManager.set_sfx_enabled(_sfx_enabled)
    _apply_graphics_settings()

func _save_game() -> void:
    _refresh_achievement_flags()
    var settings: Dictionary = _save_data.get("settings", {})
    settings["music_volume"] = _music_volume
    settings["sfx_volume"] = _sfx_volume
    settings["sfx_enabled"] = _sfx_enabled
    settings["difficulty"] = _difficulty
    settings["graphics_quality"] = _graphics_quality
    settings["fps_limit"] = _graphics_fps
    settings["graphics_profile_migrated"] = true
    _save_data["settings"] = settings
    var file := FileAccess.open(SAVE_PATH, FileAccess.WRITE)
    if file != null:
        file.store_string(JSON.stringify(_save_data, "\t"))
    _save_preferences()

func _load_preferences() -> void:
    var err := _config.load(CONFIG_PATH)
    _intro_seen = false
    if err == OK:
        _intro_seen = bool(_config.get_value("progress", "intro_seen", false))
    _music_volume = float(_config.get_value("audio", "music_volume", 0.44))
    _sfx_volume = float(_config.get_value("audio", "sfx_volume", 0.28))
    _sfx_enabled = bool(_config.get_value("audio", "sfx_enabled", true))

func _save_preferences() -> void:
    _config.set_value("progress", "intro_seen", _intro_seen)
    _config.set_value("audio", "music_volume", _music_volume)
    _config.set_value("audio", "sfx_volume", _sfx_volume)
    _config.set_value("audio", "sfx_enabled", _sfx_enabled)
    _config.save(CONFIG_PATH)

func _build_3d_world() -> void:
    _world_environment = WorldEnvironment.new()
    var env := Environment.new()
    env.background_mode = Environment.BG_COLOR
    env.background_color = Color(0.012, 0.018, 0.032)
    env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    env.ambient_light_color = Color(0.38, 0.42, 0.54)
    env.ambient_light_energy = 0.76
    env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
    env.glow_enabled = false
    env.glow_intensity = 0.12
    _world_environment.environment = env
    add_child(_world_environment)

    var sun := DirectionalLight3D.new()
    sun.name = "CinematicKeyLight"
    sun.rotation_degrees = Vector3(-43.0, -31.0, 0.0)
    sun.light_color = Color(1.0, 0.76, 0.52)
    sun.light_energy = 1.38
    sun.shadow_enabled = false
    add_child(sun)

    var fill := OmniLight3D.new()
    fill.name = "CoolArenaFill"
    fill.position = Vector3(0.0, 7.0, 7.0)
    fill.light_color = Color(0.28, 0.42, 0.78)
    fill.light_energy = 1.05
    fill.omni_range = 24.0
    add_child(fill)

    _add_cylinder(self, "ArenaFoundation", 15.0, 1.1, Vector3(0.0, -0.62, 0.0), Color(0.12, 0.105, 0.10), 64)
    _arena_floor = _add_cylinder(self, "ArenaFloor", 12.25, 0.12, Vector3(0.0, -0.025, 0.0), Color(0.36, 0.29, 0.20), 64)
    _add_torus(self, "GoldArenaRing", 12.25, 11.97, Vector3(0.0, 0.055, 0.0), GOLD)
    _add_torus(self, "InnerStoneRing", 10.75, 10.63, Vector3(0.0, 0.052, 0.0), Color(0.35, 0.28, 0.19))

    var pillar_count := 12 if _graphics_quality == "DÜŞÜK" else (16 if _graphics_quality == "ORTA" else 20)
    for i in range(pillar_count):
        var angle := TAU * float(i) / float(pillar_count)
        var pos := Vector3(cos(angle) * 14.1, 0.45, sin(angle) * 14.1)
        var pillar := _add_box(self, "WallButtress_%02d" % i, Vector3(0.75, 2.25, 0.75), pos, Color(0.20, 0.18, 0.17))
        pillar.rotation.y = -angle
        _add_box(self, "WallCap_%02d" % i, Vector3(0.9, 0.18, 0.9), pos + Vector3(0.0, 1.18, 0.0), Color(0.31, 0.25, 0.19))

    var mountain_count := 5 if _graphics_quality == "DÜŞÜK" else (7 if _graphics_quality == "ORTA" else 9)
    for i in range(mountain_count):
        var angle := TAU * float(i) / float(mountain_count)
        var radius := 28.0 + float(i % 3) * 2.6
        var mountain := MeshInstance3D.new()
        mountain.name = "HorizonMountain_%02d" % i
        var mesh := CylinderMesh.new()
        mesh.top_radius = 0.15
        mesh.bottom_radius = 5.0 + float(i % 4) * 1.1
        mesh.height = 8.5 + float(i % 5) * 2.4
        mesh.radial_segments = 6
        mountain.mesh = mesh
        mountain.position = Vector3(cos(angle) * radius, mesh.height * 0.35 - 1.5, sin(angle) * radius)
        mountain.rotation.y = angle
        mountain.material_override = _material(Color(0.045 + 0.008 * float(i % 3), 0.065, 0.105 + 0.01 * float(i % 2)))
        add_child(mountain)

    var brazier_count := 2 if _graphics_quality == "DÜŞÜK" else (3 if _graphics_quality == "ORTA" else 4)
    for i in range(brazier_count):
        var angle := TAU * float(i) / float(brazier_count)
        var p := Vector3(cos(angle) * 9.1, 0.0, sin(angle) * 9.1)
        _add_cylinder(self, "BrazierStand_%d" % i, 0.16, 1.1, p + Vector3(0.0, 0.55, 0.0), Color(0.24, 0.18, 0.12), 12)
        var flame_mat := _material(Color(1.0, 0.30, 0.07))
        flame_mat.emission_enabled = true
        flame_mat.emission = Color(1.0, 0.18, 0.035)
        flame_mat.emission_energy_multiplier = 2.0
        _add_sphere(self, "BrazierGlow_%d" % i, 0.19, p + Vector3(0.0, 1.22, 0.0), Color(1.0, 0.39, 0.07), flame_mat)
        var glow := OmniLight3D.new()
        glow.name = "BrazierLight_%d" % i
        glow.position = p + Vector3(0.0, 1.25, 0.0)
        glow.light_color = Color(1.0, 0.31, 0.08)
        glow.light_energy = 0.65
        glow.omni_range = 3.5
        add_child(glow)

    _map_decor = Node3D.new()
    _map_decor.name = "SelectedMapDecor"
    add_child(_map_decor)

    _camera = Camera3D.new()
    _camera.name = "CinematicCamera"
    _camera.fov = 47.0
    _camera.position = Vector3(0.0, 8.5, 31.0)
    add_child(_camera)
    _camera.current = true

    _menu_warriors.append(_make_warrior(Vector3(0.0, 0.0, 0.0), Color(0.37, 0.105, 0.08), Color(0.76, 0.21, 0.08)))
    _menu_warriors.append(_make_warrior(Vector3(-3.1, 0.0, -1.2), Color(0.19, 0.22, 0.26), Color(0.74, 0.55, 0.22)))
    _menu_warriors.append(_make_warrior(Vector3(3.1, 0.0, -1.5), Color(0.28, 0.21, 0.13), Color(0.76, 0.21, 0.08)))
    _menu_warriors[0].rotation.y = -0.12
    _menu_warriors[1].rotation.y = 0.30
    _menu_warriors[2].rotation.y = -0.26

func _build_ui() -> void:
    _ui_layer = CanvasLayer.new()
    _ui_layer.name = "UI"
    add_child(_ui_layer)

    _dim_layer = ColorRect.new()
    _dim_layer.color = Color(0.008, 0.012, 0.025, 0.36)
    _dim_layer.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    _ui_layer.add_child(_dim_layer)

    _intro_layer = Control.new()
    _intro_layer.name = "IntroLayer"
    _intro_layer.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    _ui_layer.add_child(_intro_layer)

    _intro_title = _make_label("SPARTA ARENA", 72, PALE_GOLD)
    _intro_title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    _intro_title.set_anchors_and_offsets_preset(Control.PRESET_TOP_WIDE)
    _intro_title.offset_left = 40.0
    _intro_title.offset_right = -40.0
    _intro_title.offset_top = 105.0
    _intro_title.offset_bottom = 200.0
    _intro_layer.add_child(_intro_title)

    _intro_subtitle = _make_label("KÜLLERDEN DOĞAN EFSANE", 23, TEXT_LIGHT)
    _intro_subtitle.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    _intro_subtitle.set_anchors_and_offsets_preset(Control.PRESET_TOP_WIDE)
    _intro_subtitle.offset_left = 40.0
    _intro_subtitle.offset_right = -40.0
    _intro_subtitle.offset_top = 203.0
    _intro_subtitle.offset_bottom = 250.0
    _intro_layer.add_child(_intro_subtitle)

    _intro_progress = ProgressBar.new()
    _intro_progress.show_percentage = false
    _intro_progress.min_value = 0.0
    _intro_progress.max_value = 100.0
    _intro_progress.value = 0.0
    _intro_progress.anchor_left = 0.12
    _intro_progress.anchor_right = 0.88
    _intro_progress.anchor_top = 1.0
    _intro_progress.anchor_bottom = 1.0
    _intro_progress.offset_top = -28.0
    _intro_progress.offset_bottom = -20.0
    _intro_layer.add_child(_intro_progress)

    var intro_caption := _make_label("13 SANİYELİK SİNEMATİK AÇILIŞ", 15, MUTED_TEXT)
    intro_caption.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    intro_caption.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_WIDE)
    intro_caption.offset_left = 30.0
    intro_caption.offset_right = -30.0
    intro_caption.offset_top = -75.0
    intro_caption.offset_bottom = -42.0
    _intro_layer.add_child(intro_caption)

    _skip_button = _make_button("ATLA  ›", 180)
    _skip_button.anchor_left = 1.0
    _skip_button.anchor_right = 1.0
    _skip_button.anchor_top = 1.0
    _skip_button.anchor_bottom = 1.0
    _skip_button.offset_left = -235.0
    _skip_button.offset_right = -48.0
    _skip_button.offset_top = -108.0
    _skip_button.offset_bottom = -50.0
    _skip_button.pressed.connect(_on_skip_pressed)
    _intro_layer.add_child(_skip_button)

    _menu_layer = Control.new()
    _menu_layer.name = "MenuLayer"
    _menu_layer.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    _ui_layer.add_child(_menu_layer)

    _menu_panel = PanelContainer.new()
    _menu_panel.name = "MenuPanel"
    _menu_panel.anchor_left = 0.045
    _menu_panel.anchor_right = 0.49
    _menu_panel.anchor_top = 0.045
    _menu_panel.anchor_bottom = 0.955
    var panel_style := StyleBoxFlat.new()
    panel_style.bg_color = Color(0.025, 0.032, 0.052, 0.94)
    panel_style.border_color = Color(0.51, 0.35, 0.15, 0.9)
    panel_style.set_border_width_all(2)
    panel_style.set_corner_radius_all(10)
    panel_style.set_content_margin_all(20.0)
    _menu_panel.add_theme_stylebox_override("panel", panel_style)
    _menu_layer.add_child(_menu_panel)

    var margin := MarginContainer.new()
    margin.add_theme_constant_override("margin_left", 12)
    margin.add_theme_constant_override("margin_right", 12)
    margin.add_theme_constant_override("margin_top", 10)
    margin.add_theme_constant_override("margin_bottom", 10)
    _menu_panel.add_child(margin)

    var content := VBoxContainer.new()
    content.add_theme_constant_override("separation", 7)
    margin.add_child(content)

    _page_title = _make_label("SPARTA ARENA", 34, PALE_GOLD)
    content.add_child(_page_title)
    _page_subtitle = _make_label("REMASTERED • SPARTA WORLD", 13, MUTED_TEXT)
    content.add_child(_page_subtitle)
    content.add_child(HSeparator.new())
    _page_body = _make_label("V57 kaynakları korunarak gerçek 3D sürüme taşınıyor.", 14, TEXT_LIGHT)
    _page_body.custom_minimum_size = Vector2(0.0, 66.0)
    _page_body.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    content.add_child(_page_body)

    _menu_scroll = ScrollContainer.new()
    _menu_scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
    _menu_scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
    content.add_child(_menu_scroll)
    _menu_buttons = VBoxContainer.new()
    _menu_buttons.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    _menu_buttons.add_theme_constant_override("separation", 5)
    _menu_scroll.add_child(_menu_buttons)

    _menu_layer.hide()
    _build_strategy_overlay()
    _build_combat_hud()

func _build_combat_hud() -> void:
    _combat_hud_layer = Control.new()
    _combat_hud_layer.name = "CombatHUD"
    _combat_hud_layer.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    _ui_layer.add_child(_combat_hud_layer)

    var left_panel := PanelContainer.new()
    left_panel.name = "CombatStatusPanel"
    left_panel.anchor_left = 0.02
    left_panel.anchor_right = 0.38
    left_panel.anchor_top = 0.025
    left_panel.anchor_bottom = 0.215
    var left_style := StyleBoxFlat.new()
    left_style.bg_color = Color(0.018, 0.032, 0.052, 0.88)
    left_style.border_color = Color(0.86, 0.60, 0.23, 0.94)
    left_style.set_border_width_all(2)
    left_style.set_corner_radius_all(10)
    left_style.set_content_margin_all(12.0)
    left_panel.add_theme_stylebox_override("panel", left_style)
    _combat_hud_layer.add_child(left_panel)

    var status_box := VBoxContainer.new()
    status_box.add_theme_constant_override("separation", 4)
    left_panel.add_child(status_box)
    status_box.add_child(_make_label("SPARTA ARENA  •  SAVAŞ", 17, PALE_GOLD))
    _combat_hud_info = _make_label("Dalga 1 • Düşman 2", 14, TEXT_LIGHT)
    _combat_hud_info.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    status_box.add_child(_combat_hud_info)
    _combat_health_bar = ProgressBar.new()
    _combat_health_bar.min_value = 0.0
    _combat_health_bar.max_value = 100.0
    _combat_health_bar.value = 100.0
    _combat_health_bar.show_percentage = false
    _combat_health_bar.custom_minimum_size = Vector2(0.0, 13.0)
    var hp_bg := StyleBoxFlat.new()
    hp_bg.bg_color = Color(0.12, 0.08, 0.08, 0.95)
    hp_bg.set_corner_radius_all(4)
    _combat_health_bar.add_theme_stylebox_override("background", hp_bg)
    var hp_fill := StyleBoxFlat.new()
    hp_fill.bg_color = Color(0.78, 0.16, 0.12)
    hp_fill.set_corner_radius_all(4)
    _combat_health_bar.add_theme_stylebox_override("fill", hp_fill)
    status_box.add_child(_combat_health_bar)
    _combat_status_label = _make_label(_combat_hud_message, 12, Color(0.76, 0.86, 0.91))
    _combat_status_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    status_box.add_child(_combat_status_label)

    var action_panel := PanelContainer.new()
    action_panel.name = "CombatActionPanel"
    action_panel.anchor_left = 0.805
    action_panel.anchor_right = 0.985
    action_panel.anchor_top = 0.025
    action_panel.anchor_bottom = 0.225
    var action_style := StyleBoxFlat.new()
    action_style.bg_color = Color(0.018, 0.032, 0.052, 0.82)
    action_style.border_color = Color(0.22, 0.69, 0.78, 0.92)
    action_style.set_border_width_all(1)
    action_style.set_corner_radius_all(10)
    action_style.set_content_margin_all(8.0)
    action_panel.add_theme_stylebox_override("panel", action_style)
    _combat_hud_layer.add_child(action_panel)
    var action_box := VBoxContainer.new()
    action_box.add_theme_constant_override("separation", 5)
    action_panel.add_child(action_box)
    var attack_button := _make_button("SALDIR  •  SPACE / SOL TIK", 0)
    attack_button.custom_minimum_size.y = 38.0
    attack_button.pressed.connect(_perform_attack)
    action_box.add_child(attack_button)
    var potion_button := _make_button("İKSİR  •  H", 0)
    potion_button.custom_minimum_size.y = 35.0
    potion_button.pressed.connect(_use_potion)
    action_box.add_child(potion_button)
    var pause_button := _make_button("DURAKLAT  •  ESC", 0)
    pause_button.custom_minimum_size.y = 35.0
    pause_button.pressed.connect(_show_pause_menu)
    action_box.add_child(pause_button)

    _combat_hud_layer.hide()

func _build_strategy_overlay() -> void:
    _strategy_layer = Control.new()
    _strategy_layer.name = "StrategyMapLayer"
    _strategy_layer.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    _ui_layer.add_child(_strategy_layer)

    _strategy_canvas = Control.new()
    _strategy_canvas.name = "StrategyCanvas"
    _strategy_canvas.set_script(load("res://scripts/strategy_map_canvas.gd"))
    _strategy_canvas.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    _strategy_canvas.mouse_filter = Control.MOUSE_FILTER_STOP
    _strategy_canvas.connect("node_clicked", Callable(self, "_on_strategy_node_clicked"))
    _strategy_layer.add_child(_strategy_canvas)

    var side_panel := PanelContainer.new()
    side_panel.name = "StrategySidePanel"
    side_panel.anchor_left = 0.735
    side_panel.anchor_right = 0.985
    side_panel.anchor_top = 0.035
    side_panel.anchor_bottom = 0.965
    var side_style := StyleBoxFlat.new()
    side_style.bg_color = Color(0.018, 0.034, 0.058, 0.97)
    side_style.border_color = Color(0.22, 0.72, 0.78, 0.95)
    side_style.set_border_width_all(2)
    side_style.set_corner_radius_all(12)
    side_style.set_content_margin_all(14.0)
    side_panel.add_theme_stylebox_override("panel", side_style)
    _strategy_layer.add_child(side_panel)

    var content := VBoxContainer.new()
    content.add_theme_constant_override("separation", 8)
    side_panel.add_child(content)

    _strategy_title = _make_label("STRATEJİ HARİTASI", 25, PALE_GOLD)
    _strategy_title.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    content.add_child(_strategy_title)
    _strategy_subtitle = _make_label("ORDU • ŞEHİRLER • DİPLOMASİ", 12, Color(0.34, 0.83, 0.90))
    _strategy_subtitle.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    content.add_child(_strategy_subtitle)
    content.add_child(HSeparator.new())

    _strategy_info = _make_label("Haritadan bir şehir seç.", 14, TEXT_LIGHT)
    _strategy_info.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    _strategy_info.custom_minimum_size = Vector2(0.0, 150.0)
    content.add_child(_strategy_info)

    var action_scroll := ScrollContainer.new()
    action_scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
    action_scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
    content.add_child(action_scroll)
    _strategy_actions = VBoxContainer.new()
    _strategy_actions.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    _strategy_actions.add_theme_constant_override("separation", 7)
    action_scroll.add_child(_strategy_actions)

    var hint := _make_label("İPUCU: Yollar birer şehir ilerler. Orduyu seçili komşu düğüme yürüt; düşman şehrinde kuşatma başlat.", 11, MUTED_TEXT)
    hint.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    content.add_child(hint)
    _strategy_layer.hide()

func _make_label(text_value: String, font_size: int, color: Color) -> Label:
    var label := Label.new()
    label.text = text_value
    label.add_theme_font_size_override("font_size", font_size)
    label.add_theme_color_override("font_color", color)
    label.add_theme_color_override("font_shadow_color", Color(0.0, 0.0, 0.0, 0.7))
    label.add_theme_constant_override("shadow_offset_x", 2)
    label.add_theme_constant_override("shadow_offset_y", 2)
    return label

func _make_button(label_text: String, min_width: int = 0) -> Button:
    var button := Button.new()
    button.text = label_text
    button.custom_minimum_size = Vector2(float(min_width), 40.0)
    button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    button.focus_mode = Control.FOCUS_ALL
    button.add_theme_font_size_override("font_size", 15)
    button.add_theme_color_override("font_color", Color(0.91, 0.95, 0.98))
    button.add_theme_color_override("font_hover_color", Color(1.0, 0.93, 0.66))
    var upper_label := label_text.to_upper()
    var accent := GOLD
    if upper_label.contains("DENİZ") or upper_label.contains("GEMİ") or upper_label.contains("BALIK") or upper_label.contains("SEFER"):
        accent = Color(0.19, 0.76, 0.88)
    elif upper_label.contains("DÜNYA") or upper_label.contains("FET") or upper_label.contains("ORDU") or upper_label.contains("KUŞAT"):
        accent = Color(0.91, 0.38, 0.25)
    elif upper_label.contains("AYAR") or upper_label.contains("GRAFİK") or upper_label.contains("SES"):
        accent = Color(0.55, 0.63, 0.98)
    elif upper_label.contains("YAPIM") or upper_label.contains("HAKKINDA"):
        accent = Color(0.48, 0.88, 0.65)
    elif upper_label.contains("OYNA") or upper_label.contains("SALDIR") or upper_label.contains("BAŞLAT"):
        accent = Color(0.97, 0.48, 0.24)
    var normal := StyleBoxFlat.new()
    normal.bg_color = Color(0.035, 0.075, 0.12, 0.97)
    normal.border_color = accent.darkened(0.12)
    normal.set_border_width_all(1)
    normal.set_corner_radius_all(7)
    normal.set_content_margin_all(7.0)
    button.add_theme_stylebox_override("normal", normal)
    var hover := normal.duplicate() as StyleBoxFlat
    hover.bg_color = accent.darkened(0.68)
    hover.border_color = accent.lightened(0.10)
    hover.set_border_width_all(2)
    button.add_theme_stylebox_override("hover", hover)
    var pressed_style := normal.duplicate() as StyleBoxFlat
    pressed_style.bg_color = accent.darkened(0.55)
    button.add_theme_stylebox_override("pressed", pressed_style)
    button.pressed.connect(_on_any_button_pressed)
    return button

func _add_menu_button(label_text: String, callback: Callable, disabled: bool = false) -> void:
    var button := _make_button(label_text)
    button.disabled = disabled
    button.pressed.connect(callback)
    _menu_buttons.add_child(button)

func _clear_menu_buttons() -> void:
    for child in _menu_buttons.get_children():
        child.queue_free()

func _set_page(title_value: String, subtitle_value: String, body_value: String) -> void:
    _menu_layer.show()
    if is_instance_valid(_dim_layer):
        _dim_layer.show()
    _intro_layer.hide()
    if is_instance_valid(_strategy_layer):
        _strategy_layer.hide()
    _menu_panel.show()
    _page_title.text = title_value
    _page_subtitle.text = subtitle_value
    _page_body.text = body_value
    _clear_menu_buttons()

func _show_menu() -> void:
    _screen_mode = "menu"
    if is_instance_valid(_combat_hud_layer):
        _combat_hud_layer.hide()
    _set_arena_visible(true)
    if is_instance_valid(_strategy_layer):
        _strategy_layer.hide()
    _menu_layer.show()
    _menu_panel.show()
    _set_page("SPARTA ARENA", "REMASTERED • SPARTA WORLD", "KILIÇ • TAHT • DENİZ • FETİH\nV57 kataloğu: 20 karakter, 9 harita, 10 mod ve 72 şehir. Strateji haritaları, ordu yürüyüşü, vali diyaloğu, diplomasi, kuşatma, deniz rotaları, gemi sağlığı, balıkçılık ve korsan savaşı eklendi. Bu hâlâ kaynak varlıkları sınırlı bir remaster prototipidir.")
    _add_menu_button("OYNA  /  TÜM OYUN MODLARI", _show_modes)
    _add_menu_button("KARAKTER SEÇİMİ", _show_characters)
    _add_menu_button("HARİTA SEÇİMİ", _show_maps)
    _add_menu_button("DÜNYA FETHİ  /  ŞEHİRLER", _show_world_conquest)
    _add_menu_button("DENİZ FETHİ  /  AÇIK DENİZ", _show_sea_world)
    _add_menu_button("MAĞAZA  /  İKSİRLER / EKİPMAN", _show_shop)
    _add_menu_button("BAŞARIMLAR", _show_achievements)
    _add_menu_button("AYARLAR  /  KONTROLLER", _show_settings)
    _add_menu_button("GELİŞTİRİCİ ARAÇLARI", _show_developer_tools)
    _add_menu_button("TANITIMI OYNAT", _begin_intro)
    _add_menu_button("YAPIMCILAR / HAKKINDA", _show_credits)
    _add_menu_button("ÇIKIŞ", _quit_game)
    for warrior in _menu_warriors:
        if is_instance_valid(warrior):
            warrior.show()
    AudioManager.play_menu_ambience()

func _show_modes() -> void:
    _screen_mode = "menu"
    _set_page("OYUN MODLARI", "V57 • 10 MOD", "Klasik dalgalar, sonsuz savaş, boss düellosu, ayıdan kaçış, tepe kontrolü, kervan savunması, sıcak patates ve kale kuşatması. Bazı modlar ayrı hedefler kullanır; V57'nin çevrim içi altyapısı ve bütün özel hareket/animasyonları kaynak paketten otomatik olarak 3D'ye çevrilemez.")
    for mode_data in _modes:
        var info: Dictionary = mode_data
        _add_menu_button(str(info.get("name", "Oyun modu")), Callable(self, "_choose_mode").bind(str(info.get("key", "classic"))))
    _add_menu_button("GERİ", _show_menu)

func _choose_mode(mode_key: String) -> void:
    _selected_mode_key = mode_key
    _show_maps()

func _show_characters() -> void:
    _show_character_page(0)

func _show_character_page(page: int) -> void:
    _screen_mode = "menu"
    var max_page := maxi(0, int(ceil(float(_characters.size()) / ITEMS_PER_PAGE)) - 1)
    var current_page := clampi(page, 0, max_page)
    var selected_name := str(_characters[int(_save_data.get("selected_character", 0))].get("name", "Spartalı"))
    _set_page("KARAKTERLER", "SAYFA %d / %d • %d KARAKTER" % [current_page + 1, max_page + 1, _characters.size()], "Seçili: %s. Karakterlerin temel hız/saldırı/savunma istatistikleri V57 listesinden aktarıldı. Görsel modeller şu an prosedürel 3D prototipidir; tarihî kişilere özel ayrıntılı model/animasyon dosyaları arşivde bulunmuyor." % selected_name)
    var first_index := current_page * ITEMS_PER_PAGE
    var last_index := mini(first_index + ITEMS_PER_PAGE, _characters.size())
    for i in range(first_index, last_index):
        var character: Dictionary = _characters[i]
        var locked := _is_character_locked(i)
        var marker := "✓ " if i == int(_save_data.get("selected_character", 0)) else ""
        var source_note := " • YENİ EKLENDİ" if not bool(character.get("source_v57", true)) else ""
        var info := "%s%s%s | Hız %.0f • Saldırı %d • Savunma %d • Can +%d%s" % [marker, str(character.get("name", "Savaşçı")), source_note, float(character.get("speed", 6.0)), int(character.get("attack", 5)), int(character.get("defense", 0)), int(character.get("hp_bonus", 0)), " • KİLİTLİ" if locked else ""]
        _add_menu_button(info, Callable(self, "_select_character").bind(i), locked)
    var prev := _make_button("‹ ÖNCEKİ", 0)
    prev.disabled = current_page <= 0
    prev.pressed.connect(Callable(self, "_show_character_page").bind(current_page - 1))
    _menu_buttons.add_child(prev)
    var next := _make_button("SONRAKİ ›", 0)
    next.disabled = current_page >= max_page
    next.pressed.connect(Callable(self, "_show_character_page").bind(current_page + 1))
    _menu_buttons.add_child(next)
    _add_menu_button("ANA MENÜ", _show_menu)

func _is_character_locked(index: int) -> bool:
    var character: Dictionary = _characters[index]
    var unlock: String = str(character.get("unlock", ""))
    var dev: Dictionary = _save_data.get("dev", {})
    if bool(dev.get("unlock_all", false)):
        return false
    if unlock == "classic5":
        return int(_save_data.get("classic_wins", 0)) < 5
    if unlock == "classic7":
        return int(_save_data.get("classic_wins", 0)) < 7
    return false

func _select_character(index: int) -> void:
    if index < 0 or index >= _characters.size() or _is_character_locked(index):
        return
    _save_data["selected_character"] = index
    _save_game()
    _show_character_page(int(index / ITEMS_PER_PAGE))

func _show_maps() -> void:
    _screen_mode = "menu"
    var mode_name := "Serbest seçim"
    for mode_data in _modes:
        if str(mode_data.get("key", "")) == _selected_mode_key:
            mode_name = str(mode_data.get("name", "Oyun modu"))
            break
    _set_page("HARİTA SEÇİMİ", "%d V57 HARİTASI • %s" % [_maps.size(), mode_name], "Harita düğmesine basınca renk/atmosfer teması değişir ve seçilen mod başlar. Bu aşamada dokuz tema 3D arena geometrisine uygulanır; her haritanın son çevre modelleri ve özel görevleri ayrıca geliştirilecek.")
    for i in range(_maps.size()):
        var map_data: Dictionary = _maps[i]
        var prefix := "✓ " if i == int(_save_data.get("selected_map", 0)) else ""
        _add_menu_button(prefix + str(map_data.get("name", "Harita")), Callable(self, "_select_map").bind(i))
    _add_menu_button("MODLARA GERİ DÖN", _show_modes)
    _add_menu_button("ANA MENÜ", _show_menu)

func _select_map(index: int) -> void:
    _save_data["selected_map"] = clampi(index, 0, _maps.size() - 1)
    _save_game()
    _apply_map_theme(int(_save_data["selected_map"]))
    _start_combat()

func _apply_map_theme(index: int) -> void:
    if _maps.is_empty() or not is_instance_valid(_arena_floor):
        return
    var safe_index := clampi(index, 0, _maps.size() - 1)
    var map_data: Dictionary = _maps[safe_index]
    var floor_color := _color_from(map_data.get("floor", []), Color(0.36, 0.29, 0.20))
    var sky_color := _color_from(map_data.get("sky", []), Color(0.012, 0.018, 0.032))
    var accent := _color_from(map_data.get("accent", []), GOLD)
    _arena_floor.material_override = _material(floor_color)
    if is_instance_valid(_world_environment) and _world_environment.environment != null:
        _world_environment.environment.background_color = sky_color
        _world_environment.environment.ambient_light_color = sky_color.lightened(0.40)
    if is_instance_valid(_map_decor):
        for child in _map_decor.get_children():
            child.queue_free()
        var theme := str(map_data.get("theme", "arena"))
        var decor_count := 4 if _graphics_quality == "DÜŞÜK" else (6 if _graphics_quality == "ORTA" else 8)
        for i in range(decor_count):
            var angle := TAU * float(i) / float(decor_count)
            var radius := 8.8 if theme != "ice" else 8.2
            var p := Vector3(cos(angle) * radius, 0.0, sin(angle) * radius)
            if theme == "desert" or theme == "temple":
                var obelisk := _add_cylinder(_map_decor, "ThemeObelisk_%d" % i, 0.20, 2.7 + float(i % 3) * 0.4, p + Vector3(0.0, 1.35, 0.0), accent, 6)
                obelisk.rotation.z = 0.10 * sin(angle)
            elif theme == "forest":
                _add_cylinder(_map_decor, "TreeTrunk_%d" % i, 0.25, 2.5, p + Vector3(0.0, 1.25, 0.0), Color(0.20, 0.12, 0.07), 8)
                _add_sphere(_map_decor, "TreeCanopy_%d" % i, 1.0, p + Vector3(0.0, 2.75, 0.0), accent)
            elif theme == "lava":
                _add_cylinder(_map_decor, "LavaSpire_%d" % i, 0.10, 2.6 + float(i % 4) * 0.3, p + Vector3(0.0, 1.25, 0.0), accent.darkened(0.35), 5)
            else:
                _add_box(_map_decor, "ThemePillar_%d" % i, Vector3(0.55, 2.2, 0.55), p + Vector3(0.0, 1.1, 0.0), accent.darkened(0.28))

func _show_shop() -> void:
    _screen_mode = "menu"
    _set_page("MAĞAZA / İKSİRLER", "ALTIN: %d" % int(_save_data.get("gold", 0)), "İksirler ve ekipman geliştirmeleri kalıcı kaydedilir. Saldırı/savunma yükseltmeleri yeni 3D savaş döngüsünde kullanılır.")
    _add_menu_button("Can İksiri +1  —  80 altın", Callable(self, "_buy_item").bind("potion", 80))
    _add_menu_button("Tam Can İksiri +1  —  120 altın", Callable(self, "_buy_item").bind("full_potion", 120))
    _add_menu_button("Kılıç Hasarı +5  —  220 altın", Callable(self, "_buy_item").bind("sword", 220))
    _add_menu_button("Zırh Savunması +2  —  180 altın", Callable(self, "_buy_item").bind("armor", 180))
    _add_menu_button("Savaş Gücü +3  —  200 altın", Callable(self, "_buy_item").bind("damage", 200))
    _add_menu_button("GERİ", _show_menu)

func _buy_item(item_key: String, cost: int) -> void:
    var gold := int(_save_data.get("gold", 0))
    var dev: Dictionary = _save_data.get("dev", {})
    if gold < cost and not bool(dev.get("infinite_gold", false)):
        _page_body.text = "Yeterli altın yok. Kazanmak için savaş modlarına gir veya deniz/dünya sistemlerini kullan."
        return
    if not bool(dev.get("infinite_gold", false)):
        _save_data["gold"] = gold - cost
    match item_key:
        "potion": _save_data["potions"] = int(_save_data.get("potions", 0)) + 1
        "full_potion": _save_data["full_potions"] = int(_save_data.get("full_potions", 0)) + 1
        "sword": _save_data["sword_level"] = int(_save_data.get("sword_level", 0)) + 1
        "armor": _save_data["armor_level"] = int(_save_data.get("armor_level", 0)) + 1
        "damage": _save_data["damage_bonus"] = int(_save_data.get("damage_bonus", 0)) + 3
    _save_game()
    _show_shop()
    _page_body.text = "Satın alma başarılı. Kalan altın: %d" % int(_save_data.get("gold", 0))

func _show_achievements() -> void:
    _screen_mode = "menu"
    var wins := int(_save_data.get("classic_wins", 0))
    var kills := int(_save_data.get("total_kills", 0))
    var sea: Dictionary = _save_data.get("sea", {})
    var cities: Array = _save_data.get("captured_cities", [])
    var rows: Array[String] = []
    rows.append("%s İlk Zafer — Herhangi bir modu kazan" % _achievement_mark("first_win", wins > 0))
    rows.append("%s Arena Ustası — 5 klasik zafer (%d/5)" % [_achievement_mark("arena_master", wins >= 5), mini(wins, 5)])
    rows.append("%s Efsane Fatih — 7 klasik zafer (%d/7)" % [_achievement_mark("fatih_unlock", wins >= 7), mini(wins, 7)])
    rows.append("%s Demir Kılıç — 150 düşman yen (%d/150)" % [_achievement_mark("iron_sword", kills >= 150), mini(kills, 150)])
    rows.append("%s Denizci — 3 gemi al (%d/3)" % [_achievement_mark("sailor", int(sea.get("ships", 0)) >= 3), mini(int(sea.get("ships", 0)), 3)])
    rows.append("%s Deniz Kaşifi — 5 ada keşfet (%d/5)" % [_achievement_mark("sea_explorer", int(sea.get("islands_discovered", 0)) >= 5), mini(int(sea.get("islands_discovered", 0)), 5)])
    rows.append("%s Şehir Fatihi — 12 şehir ele geçir (%d/12)" % [_achievement_mark("conqueror", cities.size() >= 12), mini(cities.size(), 12)])
    rows.append("%s Zengin Savaşçı — 1000 altın biriktir (%d/1000)" % [_achievement_mark("rich", int(_save_data.get("gold", 0)) >= 1000), mini(int(_save_data.get("gold", 0)), 1000)])
    rows.append("%s Boss Avcısı — 3 boss yen (%d/3)" % [_achievement_mark("boss_hunter", int(_save_data.get("mode_stats", {}).get("bosses_defeated", 0)) >= 3), mini(int(_save_data.get("mode_stats", {}).get("bosses_defeated", 0)), 3)])
    var done := 0
    for row in rows:
        if row.begins_with("✓"):
            done += 1
    _set_page("BAŞARIMLAR", "%d / %d TAMAMLANDI" % [done, rows.size()], "Başarımlar kayıt verilerinden hesaplanır; V57'deki isimlerle birlikte Remastered sürümüne ait birkaç takip ölçütü eklendi.\n\n" + "\n".join(rows))
    _add_menu_button("ANA MENÜ", _show_menu)

func _achievement_mark(_key: String, unlocked: bool) -> String:
    return "✓" if unlocked else "◇"

func _refresh_achievement_flags() -> void:
    var flags: Dictionary = _save_data.get("achievements", {})
    var sea: Dictionary = _save_data.get("sea", {})
    var cities: Array = _save_data.get("captured_cities", [])
    var stats: Dictionary = _save_data.get("mode_stats", {})
    var wins := int(_save_data.get("classic_wins", 0))
    var kills := int(_save_data.get("total_kills", 0))
    flags["first_win"] = wins > 0 or int(_save_data.get("total_games", 0)) > 0
    flags["arena_master"] = wins >= 5
    flags["fatih_unlock"] = wins >= 7
    flags["iron_sword"] = kills >= 150
    flags["sailor"] = int(sea.get("ships", 0)) >= 3
    flags["sea_explorer"] = int(sea.get("islands_discovered", 0)) >= 5
    flags["conqueror"] = cities.size() >= 12
    flags["rich"] = int(_save_data.get("gold", 0)) >= 1000
    flags["boss_hunter"] = int(stats.get("bosses_defeated", 0)) >= 3
    _save_data["achievements"] = flags

func _show_settings() -> void:
    _screen_mode = "menu"
    _set_page("AYARLAR", "SES • GRAFİK • OYNANIŞ • KONTROLLER", "Ayarlar ayrı bölümlere ayrıldı. Değişiklikler bu bilgisayardaki kullanıcı kaydına saklanır.")
    _add_menu_button("SES AYARLARI", _show_audio_settings)
    _add_menu_button("GRAFİK / PERFORMANS AYARLARI", _show_graphics_settings)
    _add_menu_button("OYNANIŞ AYARLARI", _show_gameplay_settings)
    _add_menu_button("KONTROLLER / TUŞ ATAMA", _show_controls_settings)
    _add_menu_button("GERİ", _show_menu)

func _show_audio_settings() -> void:
    _screen_mode = "menu"
    _set_page("SES AYARLARI", "MÜZİK VE SES EFEKTLERİ", "Ses seviyeleri yüzde 25 adımlarla değişir. Efektleri tamamen kapatabilirsin.")
    _add_menu_button("MÜZİK SESİ: %d%% (değiştir)" % int(round(_music_volume * 100.0)), _cycle_music_volume)
    _add_menu_button("EFEKT SESİ: %d%% (değiştir)" % int(round(_sfx_volume * 100.0)), _cycle_sfx_volume)
    _add_menu_button("EFEKT SESLERİ: %s" % ("AÇIK" if _sfx_enabled else "KAPALI"), _toggle_sfx)
    _add_menu_button("GERİ", _show_settings)

func _show_graphics_settings() -> void:
    _screen_mode = "menu"
    _set_page("GRAFİK / PERFORMANS", "GÖRSEL KALİTE VE AKICILIK", "DÜŞÜK eski/zayıf bilgisayarlar için ışık ve parıltıyı azaltır. YÜKSEK gölgeleri ve parıltıyı açar. Değişiklikler anında uygulanır.")
    _add_menu_button("GRAFİK KALİTESİ: %s (değiştir)" % _graphics_quality, _cycle_graphics_quality)
    _add_menu_button("FPS SINIRI: %d (değiştir)" % _graphics_fps, _cycle_fps_limit)
    var settings: Dictionary = _save_data.get("settings", {})
    _add_menu_button("TAM EKRAN: %s" % ("AÇIK" if bool(settings.get("fullscreen", false)) else "KAPALI"), _toggle_fullscreen)
    _add_menu_button("GERİ", _show_settings)

func _show_gameplay_settings() -> void:
    _screen_mode = "menu"
    _set_page("OYNANIŞ AYARLARI", "ZORLUK VE TUR SÜRESİ", "Bu seçenekler savaşların zorluğunu ve klasik modun hedef tur sayısını etkiler.")
    _add_menu_button("ZORLUK: %s" % _difficulty, _cycle_difficulty)
    _add_menu_button("KLASİK TUR LİMİTİ: %d" % int(_save_data.get("classic_round_limit", 30)), _cycle_round_limit)
    _add_menu_button("GÜNLÜK ÖDÜLÜ AL", _claim_daily_reward)
    _add_menu_button("GERİ", _show_settings)

func _show_controls_settings() -> void:
    _screen_mode = "menu"
    var binds: Dictionary = _save_data.get("keybinds", {})
    _set_page("KONTROLLER", "TUŞ ATAMA", "Bir düğmeye basıp yeni tuşa bas. İptal etmek için ESC.")
    _add_menu_button("İLERİ: %s" % _key_label(binds, "move_forward", KEY_W), Callable(self, "_request_rebind").bind("move_forward"))
    _add_menu_button("GERİ: %s" % _key_label(binds, "move_back", KEY_S), Callable(self, "_request_rebind").bind("move_back"))
    _add_menu_button("SOL: %s" % _key_label(binds, "move_left", KEY_A), Callable(self, "_request_rebind").bind("move_left"))
    _add_menu_button("SAĞ: %s" % _key_label(binds, "move_right", KEY_D), Callable(self, "_request_rebind").bind("move_right"))
    _add_menu_button("SALDIRI: %s" % _key_label(binds, "attack", KEY_SPACE), Callable(self, "_request_rebind").bind("attack"))
    _add_menu_button("İKSİR: %s" % _key_label(binds, "potion", KEY_H), Callable(self, "_request_rebind").bind("potion"))
    _add_menu_button("GERİ", _show_settings)

func _cycle_graphics_quality() -> void:
    if _graphics_quality == "DÜŞÜK":
        _graphics_quality = "ORTA"
    elif _graphics_quality == "ORTA":
        _graphics_quality = "YÜKSEK"
    else:
        _graphics_quality = "DÜŞÜK"
    _apply_graphics_settings()
    _apply_map_theme(int(_save_data.get("selected_map", 0)))
    _save_game()
    _show_graphics_settings()

func _cycle_fps_limit() -> void:
    if _graphics_fps == 30:
        _graphics_fps = 60
    elif _graphics_fps == 60:
        _graphics_fps = 120
    else:
        _graphics_fps = 30
    Engine.max_fps = _graphics_fps
    _save_game()
    _show_graphics_settings()

func _apply_graphics_settings() -> void:
    Engine.max_fps = _graphics_fps
    if is_instance_valid(_world_environment) and _world_environment.environment:
        var env: Environment = _world_environment.environment
        # Glow is disabled by default to avoid extra full-screen rendering cost.
        env.glow_enabled = _graphics_quality == "YÜKSEK"
        env.glow_intensity = 0.14
    for node in get_children():
        if node is DirectionalLight3D:
            (node as DirectionalLight3D).shadow_enabled = _graphics_quality == "YÜKSEK"
        elif node is OmniLight3D and str(node.name).begins_with("BrazierLight_"):
            var light := node as OmniLight3D
            light.visible = _graphics_quality == "YÜKSEK"
            light.light_energy = 0.55

func _show_credits() -> void:
    _screen_mode = "menu"
    _set_page("YAPIMCILAR", "SPARTA WORLD • KREDİLER", "SPARTA ARENA REMASTERED\n\nKURUCU / OYUN TASARIMI: SEYİT ALİ\nSTÜDYO / MARKA: SPARTA WORLD\nOyun sistemleri ve V57 kaynak göçü: Sparta Arena projesi\nMotor: Godot Engine\n\nBu sürüm aktif geliştirme aşamasındadır. Kaynakta olmayan profesyonel 3D karakter modelleri ve animasyonlar ayrıca hazırlanmalıdır. Godot ve üçüncü taraf bileşenler kendi lisanslarına tabidir.")
    _add_menu_button("ANA MENÜ", _show_menu)

func _key_label(binds: Dictionary, action: String, fallback: int) -> String:
    return OS.get_keycode_string(int(binds.get(action, fallback)))

func _request_rebind(action: String) -> void:
    _awaiting_rebind = action
    _page_body.text = "%s için yeni bir tuşa bas. İptal etmek için ESC." % action.replace("move_", "hareket ").to_upper()

func _cycle_music_volume() -> void:
    _music_volume = 0.0 if _music_volume >= 0.99 else minf(1.0, _music_volume + 0.25)
    AudioManager.set_music_volume(_music_volume)
    _save_game()
    _show_audio_settings()

func _cycle_sfx_volume() -> void:
    _sfx_volume = 0.0 if _sfx_volume >= 0.99 else minf(1.0, _sfx_volume + 0.25)
    AudioManager.set_sfx_volume(_sfx_volume)
    _save_game()
    _show_audio_settings()

func _toggle_sfx() -> void:
    _sfx_enabled = not _sfx_enabled
    AudioManager.set_sfx_enabled(_sfx_enabled)
    _save_game()
    _show_audio_settings()

func _cycle_round_limit() -> void:
    var current := int(_save_data.get("classic_round_limit", 30))
    if current == 30:
        current = 60
    elif current == 60:
        current = 90
    elif current == 90:
        current = 120
    else:
        current = 30
    _save_data["classic_round_limit"] = current
    _save_game()
    _show_gameplay_settings()

func _claim_daily_reward() -> void:
    var today := Time.get_date_string_from_system()
    if str(_save_data.get("daily_reward_date", "")) == today:
        _page_body.text = "Bugünkü günlük ödülünü zaten aldın. Yarın tekrar gel."
        return
    var reward := 100 + mini(400, int(_save_data.get("classic_wins", 0)) * 20)
    _save_data["gold"] = int(_save_data.get("gold", 0)) + reward
    _save_data["daily_reward_date"] = today
    _save_game()
    _show_gameplay_settings()
    _page_body.text = "Günlük ödül alındı: +%d altın." % reward

func _cycle_difficulty() -> void:
    if _difficulty == "KOLAY":
        _difficulty = "ORTA"
    elif _difficulty == "ORTA":
        _difficulty = "ZOR"
    else:
        _difficulty = "KOLAY"
    _save_game()
    _show_gameplay_settings()

func _toggle_fullscreen() -> void:
    var settings: Dictionary = _save_data.get("settings", {})
    var full := not bool(settings.get("fullscreen", false))
    settings["fullscreen"] = full
    _save_data["settings"] = settings
    DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_FULLSCREEN if full else DisplayServer.WINDOW_MODE_WINDOWED)
    _save_game()
    _show_graphics_settings()

func _show_developer_tools() -> void:
    _screen_mode = "menu"
    var dev: Dictionary = _save_data.get("dev", {})
    _set_page("GELİŞTİRİCİ ARAÇLARI", "TEST / HATA AYIKLAMA", "Bunlar tek oyunculu yerel test seçenekleridir; çok oyunculu adalet veya çevrim içi sunucu özelliği değildir.")
    _add_menu_button("TÜM KARAKTERLERİ AÇ: %s" % ("AÇIK" if bool(dev.get("unlock_all", false)) else "KAPALI"), _toggle_unlock_all)
    _add_menu_button("SINIRSIZ ALTIN: %s" % ("AÇIK" if bool(dev.get("infinite_gold", false)) else "KAPALI"), _toggle_infinite_gold)
    _add_menu_button("500 ALTIN TEST HEDİYESİ", _dev_gold_gift)
    _add_menu_button("KAYIT İSTATİSTİKLERİNİ SIFIRLA", _reset_progress_confirm)
    _add_menu_button("ANA MENÜ", _show_menu)

func _toggle_unlock_all() -> void:
    var dev: Dictionary = _save_data.get("dev", {})
    dev["unlock_all"] = not bool(dev.get("unlock_all", false))
    _save_data["dev"] = dev
    _save_game()
    _show_developer_tools()

func _toggle_infinite_gold() -> void:
    var dev: Dictionary = _save_data.get("dev", {})
    dev["infinite_gold"] = not bool(dev.get("infinite_gold", false))
    _save_data["dev"] = dev
    _save_game()
    _show_developer_tools()

func _dev_gold_gift() -> void:
    _save_data["gold"] = int(_save_data.get("gold", 0)) + 500
    _save_game()
    _show_developer_tools()

func _reset_progress_confirm() -> void:
    _set_page("KAYIT SIFIRLAMA", "BU İŞLEM GERİ ALINAMAZ", "Remastered kayıt dosyasındaki altın, karakter seçimi, fetih, deniz ve başarımlar sıfırlanacak. Eski V57 kaynak dosyaları etkilenmez.")
    _add_menu_button("EVET, REMASTERED KAYDINI SIFIRLA", _reset_progress)
    _add_menu_button("VAZGEÇ", _show_developer_tools)

func _reset_progress() -> void:
    _save_data = _default_save_data()
    _save_game()
    _show_menu()

func _show_world_conquest() -> void:
    _screen_mode = "strategy_world"
    _strategy_type = "world"
    _strategy_dialogue_open = false
    _sea_encounter_pending = false
    _strategy_notice = ""
    _menu_layer.hide()
    _strategy_layer.show()
    _set_arena_visible(false)
    for warrior in _menu_warriors:
        if is_instance_valid(warrior):
            warrior.hide()
    _refresh_strategy_overlay()

func _refresh_strategy_overlay() -> void:
    if not is_instance_valid(_strategy_canvas) or not is_instance_valid(_strategy_layer):
        return
    _strategy_layer.show()
    _menu_layer.hide()
    _clear_strategy_actions()
    if _strategy_type == "world":
        _screen_mode = "strategy_world"
        var continent_index := clampi(int(_save_data.get("conquest_continent", 0)), 0, maxi(_city_pools.size() - 1, 0))
        var city_names: Array = _city_pools[continent_index] if continent_index < _city_pools.size() else ["Sivas"]
        var current_city := str(_save_data.get("conquest_current_city", city_names[0]))
        if not city_names.has(current_city):
            current_city = str(city_names[0])
            _save_data["conquest_current_city"] = current_city
        var selected_city := str(_save_data.get("conquest_selected_city", current_city))
        if not city_names.has(selected_city):
            selected_city = current_city
            _save_data["conquest_selected_city"] = selected_city
        var current_index := city_names.find(current_city)
        _strategy_selected_index = maxi(city_names.find(selected_city), 0)
        var captured: Array = _save_data.get("captured_cities", [])
        var dev_settings: Dictionary = _save_data.get("dev", {})
        var infinite_gold := bool(dev_settings.get("infinite_gold", false))
        var total_cities := _city_pools.size() * 12
        var troops := int(_save_data.get("troops", 0))
        var morale := int(_save_data.get("conquest_morale", 80))
        var day := int(_save_data.get("conquest_days", 1))
        _strategy_title.text = "DÜNYA FETHİ"
        _strategy_title.add_theme_color_override("font_color", Color(0.97, 0.70, 0.29))
        _strategy_subtitle.text = "KITA %d / %d  •  ORDU  •  DİPLOMASİ" % [continent_index + 1, _city_pools.size()]
        _strategy_canvas.call("configure_map", "world", city_names, captured, [], current_index, _strategy_selected_index, day)
        _strategy_info.text = "KOMUTANIN KONUMU: %s\nBölge: %s\nKuvvet: %d asker  •  Moral: %d/100\nErzak: %d/100\nAltın: %d  •  Gün: %d\nFethedilen şehir: %d/%d\nSeçili hedef: %s (%s)" % [current_city, _continent_name(continent_index), troops, morale, int(_save_data.get("conquest_supplies", 100)), int(_save_data.get("gold", 0)), day, captured.size(), total_cities, selected_city, "DOST" if captured.has(selected_city) else _conquest_nation_for_city(_strategy_selected_index)]
        if _strategy_notice != "":
            _strategy_info.text += "\n\n" + _strategy_notice
        if _strategy_dialogue_open:
            _add_strategy_button("SAYGI SUN (30 ALTIN)", _conquest_show_respect)
            _add_strategy_button("HARAÇ TALEP ET", _conquest_demand_tribute)
            _add_strategy_button("TESLİMİ İSTE", _conquest_demand_surrender, captured.has(current_city))
            _add_strategy_button("KUŞATMAYI BAŞLAT", _begin_conquest_siege, captured.has(current_city))
            _add_strategy_button("HARİTAYA DÖN", _close_conquest_dialogue)
        else:
            var can_move := current_index != _strategy_selected_index and absi(current_index - _strategy_selected_index) == 1
            _add_strategy_button("SEÇİLİ ŞEHRE YÜRÜ", _march_to_selected_city, not can_move)
            _add_strategy_button("VALİYLE / HALKLA KONUŞ", _open_city_dialogue, current_index != _strategy_selected_index)
            _add_strategy_button("ŞEHRİ KUŞAT / SAVAŞ", _begin_conquest_siege, current_index != _strategy_selected_index or captured.has(current_city))
            _add_strategy_button("ASKER TOPLA (+10 / 80 ALTIN)", _recruit_troops)
            _add_strategy_button("ORDUYU EĞİT (+MORAL / 60)", _train_conquest_army)
            _add_strategy_button("HAN / ORDUYU DİNLENDİR (35)", _rest_conquest_army, int(_save_data.get("gold", 0)) < 35 and not infinite_gold)
            _add_strategy_button("PAZAR / ERZAK AL (+30 / 45)", _buy_conquest_supplies, int(_save_data.get("gold", 0)) < 45 and not infinite_gold)
            var owned_here := 0
            for name in city_names:
                if captured.has(name):
                    owned_here += 1
            _add_strategy_button("SONRAKİ KITAYI AÇ (%d/6 ŞEHİR)" % owned_here, _advance_conquest_continent, owned_here < 6 or continent_index >= _city_pools.size() - 1)
            _add_strategy_button("DEVLETLER / DİPLOMASİ", _open_conquest_diplomacy)
        _add_strategy_button("ANA MENÜ", _show_menu)
    else:
        _screen_mode = "strategy_sea"
        var sea: Dictionary = _save_data.get("sea", {})
        var names: Array = ["Sparta Limanı", "Sisli Adalar", "Mercan Resifi", "Korsan Koyu", "Batık Tapınak", "Kral Limanı", "Fırtına Burnu", "Altın Ada"]
        var current_sea_index := clampi(int(sea.get("current_location", 0)), 0, names.size() - 1)
        var selected_sea_index := clampi(int(sea.get("selected_location", 1)), 0, names.size() - 1)
        _strategy_selected_index = selected_sea_index
        var visited: Array = sea.get("visited_locations", [0])
        _strategy_title.text = "DENİZ FETHİ"
        _strategy_title.add_theme_color_override("font_color", Color(0.28, 0.82, 0.96))
        _strategy_subtitle.text = "AÇIK DENİZ  •  KEŞİF  •  BALIKÇILIK  •  KORSANLAR"
        _strategy_canvas.call("configure_map", "sea", names, [], visited, current_sea_index, selected_sea_index, int(sea.get("sea_days", 1)))
        _strategy_info.text = "GEMİNİN KONUMU: %s\nSeçili rota: %s\nGemi: %d  •  Gövde: %d/100\nDeniz altını: %d  •  Erzak: %d\nBalık: %d  •  Ada keşfi: %d/5\nHarita parçası: %d  •  Korsan zaferi: %d" % [names[current_sea_index], names[selected_sea_index], int(sea.get("ships", 0)), int(sea.get("ship_health", 100)), int(sea.get("gold", 300)), int(sea.get("supplies", 100)), int(sea.get("fish_caught", 0)), int(sea.get("islands_discovered", 0)), int(sea.get("map_fragments", 0)), int(sea.get("pirate_defeats", 0))]
        if _strategy_notice != "":
            _strategy_info.text += "\n\n" + _strategy_notice
        if _strategy_dialogue_open:
            _add_strategy_button("KÜÇÜK YEM (DÜŞÜK RİSK)", Callable(self, "_fish_with_bait").bind("small"))
            _add_strategy_button("BÜYÜK YEM (ORTA RİSK)", Callable(self, "_fish_with_bait").bind("large"))
            _add_strategy_button("PARILtili YEM (NADİR BALIK)", Callable(self, "_fish_with_bait").bind("rare"))
            _add_strategy_button("GERİ", _close_sea_action)
        elif _sea_encounter_pending:
            _add_strategy_button("KORSANLARLA SAVAŞ", _begin_sea_battle)
            _add_strategy_button("40 ALTIN HARAÇ ÖDE", _pay_sea_pirates)
            _add_strategy_button("ROTAYI GÖZLE", _dismiss_sea_encounter)
        else:
            _add_strategy_button("SEÇİLİ ROTAYA YELKEN AÇ", _sea_travel_to_selected, current_sea_index == selected_sea_index)
            _add_strategy_button("GEMİ SATIN AL (250)", _buy_ship, int(sea.get("ships", 0)) > 0 or int(sea.get("gold", 300)) < 250)
            _add_strategy_button("GEMİYİ ONAR (70)", _repair_ship, int(sea.get("ships", 0)) <= 0 or int(sea.get("ship_health", 100)) >= 100 or int(sea.get("gold", 0)) < 70)
            _add_strategy_button("BALIK AVI BAŞLAT", _open_fishing_menu, int(sea.get("ships", 0)) <= 0)
            _add_strategy_button("OLTAYI YÜKSELT", _upgrade_rod, int(sea.get("gold", 0)) < 120 * int(sea.get("rod_level", 1)))
            _add_strategy_button("KORSAN AVI / DENİZ SAVAŞI", _begin_sea_battle, int(sea.get("ships", 0)) <= 0)
            _add_strategy_button("ALTINI ANA ALTINA ÇEVİR", _convert_sea_gold)
            _add_strategy_button("ANA MENÜ", _show_menu)

func _clear_strategy_actions() -> void:
    if not is_instance_valid(_strategy_actions):
        return
    for child in _strategy_actions.get_children():
        _strategy_actions.remove_child(child)
        child.queue_free()

func _add_strategy_button(label_text: String, callback: Callable, disabled: bool = false) -> void:
    var button := _make_button(label_text)
    button.custom_minimum_size = Vector2(0.0, 42.0)
    button.add_theme_font_size_override("font_size", 13)
    button.disabled = disabled
    button.pressed.connect(callback)
    _strategy_actions.add_child(button)

func _on_strategy_node_clicked(index: int) -> void:
    if _strategy_type == "world":
        var continent_index := clampi(int(_save_data.get("conquest_continent", 0)), 0, maxi(_city_pools.size() - 1, 0))
        if continent_index >= _city_pools.size() or index < 0 or index >= _city_pools[continent_index].size():
            return
        var cities: Array = _city_pools[continent_index]
        _save_data["conquest_selected_city"] = str(cities[index])
        _strategy_selected_index = index
    else:
        var sea: Dictionary = _save_data.get("sea", {})
        sea["selected_location"] = clampi(index, 0, 7)
        _save_data["sea"] = sea
        _strategy_selected_index = index
    _strategy_dialogue_open = false
    _strategy_notice = ""
    _refresh_strategy_overlay()

func _set_arena_visible(is_visible: bool) -> void:
    for child in get_children():
        if child is Node3D:
            (child as Node3D).visible = is_visible

func _continent_name(index: int) -> String:
    var names := ["Orta Topraklar", "Doğu Bozkırları", "Kuzey Buz Diyarı", "Ejderha Kıyıları", "Güney Sultanlıkları", "Efsaneler Kıtası"]
    return names[clampi(index, 0, names.size() - 1)]

func _conquest_nation_for_city(index: int) -> String:
    var nations := ["Sparta", "Roma", "Hun", "Pers", "Kuzey Krallığı", "Çöl Sultanlığı"]
    return nations[posmod(index + int(_save_data.get("conquest_continent", 0)), nations.size())]

func _march_to_selected_city() -> void:
    _strategy_notice = ""
    var continent_index := clampi(int(_save_data.get("conquest_continent", 0)), 0, maxi(_city_pools.size() - 1, 0))
    if continent_index >= _city_pools.size():
        return
    var cities: Array = _city_pools[continent_index]
    var current_index := cities.find(str(_save_data.get("conquest_current_city", cities[0])))
    var target_index := cities.find(str(_save_data.get("conquest_selected_city", cities[0])))
    if target_index < 0 or current_index < 0 or absi(target_index - current_index) != 1:
        _strategy_notice = "Ordu yalnızca yol üzerindeki komşu şehre ilerleyebilir. Haritadaki bir sonraki düğümü seç."
        _refresh_strategy_overlay()
        return
    var morale := int(_save_data.get("conquest_morale", 80))
    var troops := int(_save_data.get("troops", 0))
    if troops <= 0:
        _strategy_notice = "Orduda asker kalmadı. Orduyu yeniden kurmak için asker topla."
        _refresh_strategy_overlay()
        return
    _save_data["conquest_current_city"] = str(cities[target_index])
    _save_data["conquest_days"] = int(_save_data.get("conquest_days", 1)) + 1
    _save_data["conquest_morale"] = maxi(0, morale - 2)
    var supplies := maxi(0, int(_save_data.get("conquest_supplies", 100)) - 6)
    _save_data["conquest_supplies"] = supplies
    if supplies == 0:
        _save_data["conquest_morale"] = maxi(0, int(_save_data.get("conquest_morale", 80)) - 5)
        _save_data["troops"] = maxi(0, int(_save_data.get("troops", 0)) - 1)
        _strategy_notice = "Erzak bitti! Açlık moralini düşürdü ve bir asker ordudan ayrıldı. Pazardan erzak al."
    if randf() < 0.16:
        var losses := mini(troops, randi_range(1, 3))
        _save_data["troops"] = troops - losses
        _save_data["gold"] = int(_save_data.get("gold", 0)) + 25
        _strategy_notice = "Yol haydutlarının pususunu atlattın. %d asker kaybedildi, haydut ganimeti +25 altın." % losses
    elif _strategy_notice == "":
        _strategy_notice = "%s şehrine ulaştın. Ordu bir gün ilerledi; moral 2 azaldı." % cities[target_index]
    _save_game()
    _refresh_strategy_overlay()

func _open_city_dialogue() -> void:
    _strategy_dialogue_open = true
    var city := str(_save_data.get("conquest_current_city", "Sivas"))
    var owned: Array = _save_data.get("captured_cities", [])
    if owned.has(city):
        _strategy_notice = "%s valisi seni müttefik olarak karşılıyor. Vergi, asker ve yerel destek üzerine konuşabilirsin." % city
    else:
        _strategy_notice = "%s valisi kapılarını kapattı. Saygı göstererek ilişki kurabilir, haraç talep edebilir veya teslim olmasını isteyebilirsin." % city
    _refresh_strategy_overlay()

func _close_conquest_dialogue() -> void:
    _strategy_dialogue_open = false
    _strategy_notice = ""
    _refresh_strategy_overlay()

func _conquest_show_respect() -> void:
    var gold := int(_save_data.get("gold", 0))
    if gold < 30:
        _strategy_notice = "Elçi göndermek için 30 altın gerekiyor."
    else:
        _save_data["gold"] = gold - 30
        _save_data["conquest_reputation"] = int(_save_data.get("conquest_reputation", 0)) + 8
        var relations: Dictionary = _save_data.get("conquest_relations", {})
        var nation := _conquest_nation_for_city(_strategy_selected_index)
        relations[nation] = mini(100, int(relations.get(nation, 0)) + 12)
        _save_data["conquest_relations"] = relations
        _strategy_notice = "Elçin kabul edildi. %s ile ilişkiler iyileşti; itibar +8." % nation
        _save_game()
    _refresh_strategy_overlay()

func _conquest_demand_tribute() -> void:
    var city := str(_save_data.get("conquest_current_city", "Sivas"))
    var owned: Array = _save_data.get("captured_cities", [])
    var relations: Dictionary = _save_data.get("conquest_relations", {})
    var nation := _conquest_nation_for_city(_strategy_selected_index)
    if owned.has(city):
        _strategy_notice = "Bu şehir zaten sana ait; haraç talep etmek yerine vergi geliri için bir sonraki turda geri gel."
    elif int(relations.get(nation, 0)) < -20:
        var troops := int(_save_data.get("troops", 0))
        var losses := mini(troops, randi_range(1, 3))
        _save_data["troops"] = troops - losses
        _save_data["conquest_morale"] = maxi(0, int(_save_data.get("conquest_morale", 80)) - 8)
        _strategy_notice = "Talep reddedildi ve sınır muhafızları saldırdı. %d asker kaybedildi." % losses
    else:
        _save_data["gold"] = int(_save_data.get("gold", 0)) + 35
        relations[nation] = int(relations.get(nation, 0)) - 14
        _save_data["conquest_relations"] = relations
        _strategy_notice = "Sınır vergisi alındı: +35 altın. %s ile ilişkiler bozuldu." % nation
    _save_game()
    _refresh_strategy_overlay()

func _conquest_demand_surrender() -> void:
    var city := str(_save_data.get("conquest_current_city", "Sivas"))
    var owned: Array = _save_data.get("captured_cities", [])
    if owned.has(city):
        _strategy_notice = "Bu şehir zaten senin yönetiminde."
    else:
        var troops := int(_save_data.get("troops", 0))
        var rep := int(_save_data.get("conquest_reputation", 0))
        var chance := clampf(0.12 + float(troops) / 120.0 + float(rep) / 200.0, 0.05, 0.78)
        if randf() <= chance:
            owned.append(city)
            _save_data["captured_cities"] = owned
            _save_data["gold"] = int(_save_data.get("gold", 0)) + 90
            _save_data["conquest_morale"] = mini(100, int(_save_data.get("conquest_morale", 80)) + 8)
            _strategy_notice = "%s savaşmadan teslim oldu! +90 altın ve +8 moral." % city
        else:
            _save_data["conquest_reputation"] = maxi(-100, rep - 5)
            _strategy_notice = "Vali teslim olmayı reddetti. İtibarın 5 azaldı; gerekirse kuşatma başlat."
    _save_game()
    _strategy_dialogue_open = false
    _refresh_strategy_overlay()

func _begin_conquest_siege() -> void:
    var city := str(_save_data.get("conquest_current_city", "Sivas"))
    var owned: Array = _save_data.get("captured_cities", [])
    if owned.has(city):
        _strategy_notice = "Bu şehir zaten kontrolünde. Komşu şehre ilerle."
        _refresh_strategy_overlay()
        return
    var troops := int(_save_data.get("troops", 0))
    if troops < 5:
        _strategy_notice = "Kuşatma için en az 5 asker gerekiyor. Asker topla veya önceki savaşlardan sağ çık."
        _refresh_strategy_overlay()
        return
    _save_data["troops"] = troops - 4
    _save_data["conquest_morale"] = maxi(0, int(_save_data.get("conquest_morale", 80)) - 5)
    _conquest_battle_target = city
    _sea_battle_active = false
    _selected_mode_key = "castle"
    _save_game()
    _start_combat()

func _train_conquest_army() -> void:
    var gold := int(_save_data.get("gold", 0))
    if gold < 60:
        _strategy_notice = "Eğitim için 60 altın gerekiyor."
    else:
        _save_data["gold"] = gold - 60
        _save_data["conquest_morale"] = mini(100, int(_save_data.get("conquest_morale", 80)) + 18)
        _strategy_notice = "Ordunun morali ve disiplini yükseldi: +18 moral."
        _save_game()
    _refresh_strategy_overlay()


func _rest_conquest_army() -> void:
    var gold := int(_save_data.get("gold", 0))
    var dev: Dictionary = _save_data.get("dev", {})
    if gold < 35 and not bool(dev.get("infinite_gold", false)):
        _strategy_notice = "Han ve ordu kampı 35 altın istiyor."
    else:
        if not bool(dev.get("infinite_gold", false)):
            _save_data["gold"] = gold - 35
        _save_data["conquest_morale"] = mini(100, int(_save_data.get("conquest_morale", 80)) + 25)
        _save_data["conquest_supplies"] = mini(100, int(_save_data.get("conquest_supplies", 100)) + 8)
        _save_data["conquest_days"] = int(_save_data.get("conquest_days", 1)) + 1
        _strategy_notice = "Ordu bir gece dinlendi: moral yükseldi, erzak tazelendi. Bir gün geçti."
        _save_game()
    _refresh_strategy_overlay()

func _buy_conquest_supplies() -> void:
    var gold := int(_save_data.get("gold", 0))
    var supplies := int(_save_data.get("conquest_supplies", 100))
    var dev: Dictionary = _save_data.get("dev", {})
    if supplies >= 100:
        _strategy_notice = "Erzak zaten dolu."
    elif gold < 45 and not bool(dev.get("infinite_gold", false)):
        _strategy_notice = "Erzak kervanı için 45 altın gerekiyor."
    else:
        if not bool(dev.get("infinite_gold", false)):
            _save_data["gold"] = gold - 45
        _save_data["conquest_supplies"] = mini(100, supplies + 30)
        _strategy_notice = "Erzak kervanı geldi. Ordunun erzağı %d/100 oldu." % int(_save_data["conquest_supplies"])
        _save_game()
    _refresh_strategy_overlay()

func _advance_conquest_continent() -> void:
    var continent_index := clampi(int(_save_data.get("conquest_continent", 0)), 0, maxi(_city_pools.size() - 1, 0))
    if continent_index >= _city_pools.size() - 1:
        _strategy_notice = "Son kıtadasın; dünya fethi için tüm şehirleri ele geçir."
        _refresh_strategy_overlay()
        return
    var captured: Array = _save_data.get("captured_cities", [])
    var local_owned := 0
    for city in _city_pools[continent_index]:
        if captured.has(city):
            local_owned += 1
    if local_owned < 6:
        _strategy_notice = "Yeni kıta geçidi açılmadı. Önce bu kıtada en az 6 şehir ele geçir. (%d/6)" % local_owned
        _refresh_strategy_overlay()
        return
    _save_data["conquest_continent"] = continent_index + 1
    var next_cities: Array = _city_pools[continent_index + 1]
    _save_data["conquest_current_city"] = str(next_cities[0])
    _save_data["conquest_selected_city"] = str(next_cities[1])
    _save_data["conquest_days"] = int(_save_data.get("conquest_days", 1)) + 1
    _strategy_notice = "Yeni kıta açıldı: %s. Ordu limandan yeni yola çıktı." % _continent_name(continent_index + 1)
    _save_game()
    _refresh_strategy_overlay()

func _open_conquest_diplomacy() -> void:
    var relations: Dictionary = _save_data.get("conquest_relations", {})
    _strategy_notice = "DEVLETLER / DİPLOMASİ\n" 
    for nation in relations.keys():
        var relation_value := int(relations[nation])
        var status := "MÜTTEFİK" if relation_value >= 35 else ("DÜŞMAN" if relation_value <= -20 else "TARAFSIZ")
        _strategy_notice += "%s: %d (%s)\n" % [str(nation), relation_value, status]
    _strategy_notice += "Valilerle konuşmak ilişkileri değiştirir. Şehir kuşatması devletle ilişkileri ve itibarını etkiler."
    _strategy_dialogue_open = false
    _refresh_strategy_overlay()

func _show_sea_world() -> void:
    _screen_mode = "strategy_sea"
    _strategy_type = "sea"
    _strategy_dialogue_open = false
    _strategy_notice = ""
    _sea_encounter_pending = false
    _menu_layer.hide()
    _strategy_layer.show()
    _set_arena_visible(false)
    for warrior in _menu_warriors:
        if is_instance_valid(warrior):
            warrior.hide()
    _refresh_strategy_overlay()

func _sea_travel_to_selected() -> void:
    _strategy_notice = ""
    var sea: Dictionary = _save_data.get("sea", {})
    var current := int(sea.get("current_location", 0))
    var target := int(sea.get("selected_location", 1))
    if int(sea.get("ships", 0)) <= 0:
        _strategy_notice = "Açık denize çıkmak için önce limandan bir gemi satın al."
        _refresh_strategy_overlay()
        return
    if absi(target - current) != 1:
        _strategy_notice = "Güvenli rota düğüm düğüm ilerler. Önce rotadaki bir sonraki liman veya adayı seç."
        _refresh_strategy_overlay()
        return
    var gold := int(sea.get("gold", 0))
    if gold < 12:
        _strategy_notice = "Yelken ve tayfa masrafı için en az 12 deniz altını gerekiyor."
        _refresh_strategy_overlay()
        return
    sea["gold"] = gold - 12
    sea["current_location"] = target
    sea["sea_days"] = int(sea.get("sea_days", 1)) + 1
    sea["supplies"] = maxi(0, int(sea.get("supplies", 100)) - 7)
    var health := int(sea.get("ship_health", 100))
    if int(sea["supplies"]) == 0:
        health = maxi(0, health - 5)
        sea["gold"] = maxi(0, int(sea.get("gold", 0)) - 5)
    if target == 3:
        _sea_encounter_pending = true
        _strategy_notice = "Korsan yelkenleri görüldü! Savaşı seçebilir veya 40 altın ödeyerek geçiş izni alabilirsin."
    elif target == 6 and randf() < 0.62:
        var damage := randi_range(10, 24)
        health = maxi(0, health - damage)
        _strategy_notice = "FIRTINA! Gemi gövdesi %d hasar aldı." % damage
    else:
        var reward := randi_range(18, 48)
        sea["gold"] = int(sea.get("gold", 0)) + reward
        _strategy_notice = "%s rotasına ulaştın. Yüzen enkazdan +%d deniz altını topladın." % [["Sparta Limanı", "Sisli Adalar", "Mercan Resifi", "Korsan Koyu", "Batık Tapınak", "Kral Limanı", "Fırtına Burnu", "Altın Ada"][target], reward]
    if int(sea.get("supplies", 100)) == 0:
        _strategy_notice += "\nERZAK TÜKENDİ: Gemi 5 hasar aldı ve 5 deniz altını harcandı."
    sea["ship_health"] = health
    var visited: Array = sea.get("visited_locations", [0])
    if not visited.has(target):
        visited.append(target)
        if target in [1, 2, 4, 6, 7]:
            sea["islands_discovered"] = mini(5, int(sea.get("islands_discovered", 0)) + 1)
            sea["map_fragments"] = int(sea.get("map_fragments", 0)) + 1
            if randf() < 0.16:
                sea["relics"] = int(sea.get("relics", 0)) + 1
                _strategy_notice += " EFSANE KALINTI BULUNDU!"
    sea["visited_locations"] = visited
    _save_data["sea"] = sea
    if health <= 0:
        var ships := maxi(0, int(sea.get("ships", 0)) - 1)
        sea["ships"] = ships
        sea["ship_health"] = 100 if ships > 0 else 0
        _save_data["sea"] = sea
        _strategy_notice += " Gemi kullanılamaz hale geldi; limanda yeni gemi alman gerekiyor."
    _save_game()
    _refresh_strategy_overlay()

func _open_fishing_menu() -> void:
    _strategy_dialogue_open = true
    _strategy_notice = "Yemi seç. Daha pahalı yem nadir balık şansını artırır; olta seviyesi kazancı yükseltir."
    _refresh_strategy_overlay()

func _close_sea_action() -> void:
    _strategy_dialogue_open = false
    _strategy_notice = ""
    _refresh_strategy_overlay()

func _fish_with_bait(kind: String) -> void:
    var sea: Dictionary = _save_data.get("sea", {})
    var cost := 4
    var chance := 0.72
    var base_reward := 18
    if kind == "large":
        cost = 12
        chance = 0.78
        base_reward = 42
    elif kind == "rare":
        cost = 25
        chance = 0.68
        base_reward = 95
    if int(sea.get("ships", 0)) <= 0:
        _strategy_notice = "Balık avı için gemin olmalı."
    elif int(sea.get("gold", 0)) < cost:
        _strategy_notice = "Yem için %d deniz altını gerekiyor." % cost
    else:
        sea["gold"] = int(sea.get("gold", 0)) - cost
        chance = clampf(chance + float(int(sea.get("rod_level", 1)) - 1) * 0.035, 0.2, 0.92)
        if randf() <= chance:
            var reward := randi_range(int(base_reward * 0.65), int(base_reward * 1.35)) * int(sea.get("rod_level", 1))
            sea["fish_caught"] = int(sea.get("fish_caught", 0)) + 1
            sea["gold"] = int(sea.get("gold", 0)) + reward
            _strategy_notice = "OLTA GERİ ÇEKİLDİ! Balık yakaladın. +%d deniz altını." % reward
            if kind == "rare" and randf() < 0.30:
                sea["relics"] = int(sea.get("relics", 0)) + 1
                sea["map_fragments"] = int(sea.get("map_fragments", 0)) + 1
                _strategy_notice += " Nadide bir deniz kalıntısı da buldun!"
        else:
            _strategy_notice = "Balık oltadan kurtuldu. Yem boşa gitti; olta yükseltmesi şansını artırır."
        _save_data["sea"] = sea
        _save_game()
    _strategy_dialogue_open = false
    _refresh_strategy_overlay()

func _repair_ship() -> void:
    var sea: Dictionary = _save_data.get("sea", {})
    if int(sea.get("ships", 0)) <= 0:
        _strategy_notice = "Onarılacak gemin yok. Limandan gemi al."
    elif int(sea.get("gold", 0)) < 70:
        _strategy_notice = "Gemi onarımı 70 deniz altını gerekiyor."
    else:
        sea["gold"] = int(sea.get("gold", 0)) - 70
        sea["ship_health"] = mini(100, int(sea.get("ship_health", 100)) + 45)
        _save_data["sea"] = sea
        _strategy_notice = "Gövde onarıldı. Gemi sağlığı: %d/100." % int(sea["ship_health"])
        _save_game()
    _refresh_strategy_overlay()

func _begin_sea_battle() -> void:
    var sea: Dictionary = _save_data.get("sea", {})
    if int(sea.get("ships", 0)) <= 0:
        _strategy_notice = "Savaş için önce gemi satın almalısın."
        _refresh_strategy_overlay()
        return
    _sea_battle_active = true
    _conquest_battle_target = ""
    _selected_mode_key = "storm"
    _save_game()
    _start_combat()

func _pay_sea_pirates() -> void:
    var sea: Dictionary = _save_data.get("sea", {})
    if int(sea.get("gold", 0)) < 40:
        _strategy_notice = "Korsan geçiş izni 40 deniz altını."
    else:
        sea["gold"] = int(sea.get("gold", 0)) - 40
        sea["current_location"] = int(sea.get("selected_location", 3))
        _save_data["sea"] = sea
        _sea_encounter_pending = false
        _strategy_notice = "40 deniz altını haraç verildi. Korsanlar geçişe izin verdi; gemi ve tayfa korunuyor."
        _save_game()
    _refresh_strategy_overlay()

func _dismiss_sea_encounter() -> void:
    var sea: Dictionary = _save_data.get("sea", {})
    sea["current_location"] = maxi(0, int(sea.get("current_location", 0)) - 1)
    sea["selected_location"] = int(sea["current_location"])
    sea["supplies"] = maxi(0, int(sea.get("supplies", 100)) - 4)
    _save_data["sea"] = sea
    _save_game()
    _sea_encounter_pending = false
    _strategy_notice = "Kaptan korsan koyundan geri çekildi. Bir miktar erzak harcandı; başka rota seçebilirsin."
    _refresh_strategy_overlay()

func _capture_next_city() -> void:
    var cities: Array = _save_data.get("captured_cities", [])
    var total_cities := _city_pools.size() * 12
    if cities.size() >= total_cities:
        _show_world_conquest()
        return
    var continent_index := clampi(int(_save_data.get("conquest_continent", 0)), 0, maxi(_city_pools.size() - 1, 0))
    var target_name := ""
    if continent_index < _city_pools.size():
        for candidate in _city_pools[continent_index]:
            if not cities.has(candidate):
                target_name = str(candidate)
                break
    if target_name == "":
        _page_body.text = "Bu kıtadaki şehirlerin tamamı fethedildi. Sonraki kıtaya geç."
        return
    var dev: Dictionary = _save_data.get("dev", {})
    if int(_save_data.get("gold", 0)) < 100 and not bool(dev.get("infinite_gold", false)):
        _page_body.text = "Şehir seferi için en az 100 altın gerekiyor."
        return
    if not bool(dev.get("infinite_gold", false)):
        _save_data["gold"] = int(_save_data.get("gold", 0)) - 100
    cities.append(target_name)
    _save_data["captured_cities"] = cities
    _save_data["gold"] = int(_save_data.get("gold", 0)) + 160
    _save_game()
    _show_world_conquest()
    _page_body.text = "%s fethedildi! +160 altın. Toplam şehir: %d" % [target_name, cities.size()]

func _recruit_troops() -> void:
    var dev: Dictionary = _save_data.get("dev", {})
    if int(_save_data.get("gold", 0)) < 80 and not bool(dev.get("infinite_gold", false)):
        if _screen_mode == "strategy_world":
            _strategy_notice = "Asker toplamak için 80 altın gerekiyor."
            _refresh_strategy_overlay()
        else:
            _page_body.text = "Asker toplamak için 80 altın gerekiyor."
        return
    if not bool(dev.get("infinite_gold", false)):
        _save_data["gold"] = int(_save_data.get("gold", 0)) - 80
    _save_data["troops"] = int(_save_data.get("troops", 0)) + 10
    _save_game()
    _show_world_conquest()

func _next_continent() -> void:
    _advance_conquest_continent()

func _fish_now() -> void:
    _open_fishing_menu()

func _explore_sea() -> void:
    var sea: Dictionary = _save_data.get("sea", {})
    if int(sea.get("gold", 300)) < 75:
        _page_body.text = "Keşif için 75 deniz altını gerekiyor. Önce balık tut."
        return
    sea["gold"] = int(sea.get("gold", 300)) - 75
    sea["sea_runs"] = int(sea.get("sea_runs", 0)) + 1
    if int(sea.get("islands_discovered", 0)) < 5:
        sea["islands_discovered"] = int(sea.get("islands_discovered", 0)) + 1
        sea["map_fragments"] = int(sea.get("map_fragments", 0)) + 1
    var reward := randi_range(55, 125)
    sea["gold"] = int(sea.get("gold", 0)) + reward
    var stats: Dictionary = _save_data.get("mode_stats", {})
    stats["sea_runs"] = int(stats.get("sea_runs", 0)) + 1
    _save_data["mode_stats"] = stats
    _save_data["sea"] = sea
    _save_game()
    _show_sea_world()
    _page_body.text += "\nKeşif tamamlandı; +%d deniz altını ve harita parçası." % reward

func _upgrade_rod() -> void:
    var sea: Dictionary = _save_data.get("sea", {})
    var cost := 120 * int(sea.get("rod_level", 1))
    if int(sea.get("gold", 300)) < cost:
        if _screen_mode == "strategy_sea":
            _strategy_notice = "Olta yükseltmesi için %d deniz altını gerekiyor." % cost
            _refresh_strategy_overlay()
        else:
            _page_body.text = "Olta yükseltmesi için %d deniz altını gerekiyor." % cost
        return
    sea["gold"] = int(sea.get("gold", 0)) - cost
    sea["rod_level"] = int(sea.get("rod_level", 1)) + 1
    _save_data["sea"] = sea
    _save_game()
    _show_sea_world()

func _buy_ship() -> void:
    var sea: Dictionary = _save_data.get("sea", {})
    if int(sea.get("gold", 300)) < 250:
        if _screen_mode == "strategy_sea":
            _strategy_notice = "Gemi için 250 deniz altını gerekiyor. Balık avla veya rotalardan ganimet topla."
            _refresh_strategy_overlay()
        else:
            _page_body.text = "Gemi için 250 deniz altını gerekiyor."
        return
    sea["gold"] = int(sea.get("gold", 0)) - 250
    sea["ships"] = int(sea.get("ships", 0)) + 1
    sea["ship_health"] = 100
    _save_data["sea"] = sea
    _save_game()
    _show_sea_world()

func _convert_sea_gold() -> void:
    var sea: Dictionary = _save_data.get("sea", {})
    var amount := int(sea.get("gold", 0))
    var convert := int(amount / 2)
    sea["gold"] = amount - convert
    _save_data["gold"] = int(_save_data.get("gold", 0)) + convert
    _save_data["sea"] = sea
    _save_game()
    _show_sea_world()

func _start_combat() -> void:
    _screen_mode = "combat"
    _set_arena_visible(true)
    _menu_layer.show()
    if is_instance_valid(_strategy_layer):
        _strategy_layer.hide()
    _combat_ended = false
    _animation_clock = 0.0
    _attack_swing_time = 0.0
    _attack_was_down = false
    _potion_was_down = false
    _wave_transition_pending = false
    _wave_delay = 0.0
    _wave = 0
    _kills_this_run = 0
    _hill_progress = 0.0
    _caravan_health = 100.0
    _potato_holder = "player"
    _mode_time_left = 25.0 if _selected_mode_key == "hot_potato" else 90.0
    _attack_cooldown = 0.0
    _enemy_hit_cooldown = 0.0
    _combat_max_health = 100.0 + float(_current_character().get("hp_bonus", 0)) + float(_save_data.get("armor_level", 0)) * 5.0
    _combat_health = _combat_max_health
    for warrior in _menu_warriors:
        if is_instance_valid(warrior):
            warrior.hide()
    _clear_combat_nodes()
    var character: Dictionary = _current_character()
    _player = _make_warrior(Vector3(0.0, 0.0, 5.0), _color_from(character.get("armor", []), Color(0.6, 0.4, 0.2)), _color_from(character.get("cape", []), Color(0.7, 0.15, 0.1)))
    _player.name = "PlayerCharacter"
    _camera.position = Vector3(0.0, 6.5, 15.0)
    _camera.look_at(_player.position + Vector3(0.0, 1.1, -1.0), Vector3.UP)
    _set_page("SAVAŞ", str(_current_mode_name()) + " • " + str(_current_map_name()), "")
    _clear_menu_buttons()
    _menu_layer.hide()
    if is_instance_valid(_dim_layer):
        _dim_layer.hide()
    if is_instance_valid(_combat_hud_layer):
        _combat_hud_layer.show()
    _combat_hud_message = "Düşmana yaklaş ve saldır. Düşman canı başının üstünde gösterilir."
    _set_combat_message(_combat_hud_message)
    Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
    _spawn_wave()
    _refresh_combat_hud()
    AudioManager.play_menu_ambience()

func _clear_combat_nodes() -> void:
    for enemy in _enemies:
        var node: Node3D = enemy.get("node")
        if is_instance_valid(node):
            node.queue_free()
    _enemies.clear()
    if is_instance_valid(_player):
        _player.queue_free()
    _player = null

func _spawn_wave() -> void:
    _wave += 1
    _wave_transition_pending = false
    var mode_key := _selected_mode_key
    var is_boss := mode_key == "boss" or mode_key == "storm" or mode_key == "bear" or (mode_key == "classic" and _wave % 10 == 0)
    var enemy_cap := 4 if _graphics_quality != "YÜKSEK" else 5
    var enemy_count := 1 if is_boss else clampi(2 + _wave, 2, enemy_cap)
    if mode_key == "boss" or mode_key == "storm" or mode_key == "bear":
        enemy_count = 1
    elif mode_key == "hide_seek":
        enemy_count = 3
    for i in range(enemy_count):
        var angle := TAU * float(i) / float(maxi(enemy_count, 1)) + randf_range(-0.15, 0.15)
        var radius := 6.0 + randf_range(0.0, 2.2)
        var position := Vector3(cos(angle) * radius, 0.0, sin(angle) * radius - 0.4)
        var color := Color(0.18 + randf() * 0.15, 0.20, 0.23)
        var crest := Color(0.52, 0.12, 0.08) if not is_boss else Color(0.80, 0.17, 0.045)
        var enemy_node := _make_warrior(position, color, crest)
        enemy_node.name = "Enemy_%d_%d" % [_wave, i]
        var hp := 34.0 + float(_wave) * 10.0
        if mode_key == "hide_seek":
            hp = 30.0 + float(_wave) * 4.0
        if is_boss:
            hp = 260.0 + float(_wave) * 24.0
            if mode_key == "bear":
                hp = 360.0 + float(_wave) * 30.0
            enemy_node.scale = Vector3(1.7, 1.7, 1.7)
        var health_label := Label3D.new()
        health_label.name = "EnemyHealthLabel"
        health_label.text = "CAN %d / %d" % [int(hp), int(hp)]
        health_label.position = Vector3(0.0, 2.9 / maxf(enemy_node.scale.y, 0.01), 0.0)
        health_label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
        health_label.font_size = 56
        health_label.pixel_size = 0.006
        health_label.outline_size = 8
        health_label.modulate = Color(1.0, 0.56, 0.42)
        enemy_node.add_child(health_label)
        _enemies.append({"node":enemy_node, "hp_label":health_label, "hp":hp, "max_hp":hp, "boss":is_boss, "cooldown":randf_range(0.3, 0.9), "dead":false})
    _refresh_combat_hud()

func _update_combat(delta: float) -> void:
    if not is_instance_valid(_player) or _combat_ended:
        return
    _animation_clock += delta
    _attack_swing_time = maxf(0.0, _attack_swing_time - delta)
    _attack_cooldown = maxf(0.0, _attack_cooldown - delta)
    _enemy_hit_cooldown = maxf(0.0, _enemy_hit_cooldown - delta)
    var direction := Vector3.ZERO
    if _is_bound_pressed("move_forward", KEY_W) or Input.is_key_pressed(KEY_UP):
        direction.z -= 1.0
    if _is_bound_pressed("move_back", KEY_S) or Input.is_key_pressed(KEY_DOWN):
        direction.z += 1.0
    if _is_bound_pressed("move_left", KEY_A) or Input.is_key_pressed(KEY_LEFT):
        direction.x -= 1.0
    if _is_bound_pressed("move_right", KEY_D) or Input.is_key_pressed(KEY_RIGHT):
        direction.x += 1.0
    var player_is_moving := direction.length() > 0.01
    _animate_warrior(_player, player_is_moving, _animation_clock)
    if player_is_moving:
        direction = direction.normalized()
        var move_speed := float(_current_character().get("speed", 6.0)) * 0.58
        _player.position += direction * move_speed * delta
        _player.position.x = clampf(_player.position.x, -10.3, 10.3)
        _player.position.z = clampf(_player.position.z, -10.3, 10.3)
        _player.rotation.y = atan2(-direction.x, -direction.z)

    var attack_down := _is_bound_pressed("attack", KEY_SPACE) or Input.is_mouse_button_pressed(MOUSE_BUTTON_LEFT)
    if attack_down and not _attack_was_down and _attack_cooldown <= 0.0:
        _perform_attack()
    _attack_was_down = attack_down
    var potion_down := _is_bound_pressed("potion", KEY_H)
    if potion_down and not _potion_was_down:
        _use_potion()
    _potion_was_down = potion_down

    for i in range(_enemies.size()):
        var enemy_data: Dictionary = _enemies[i]
        var node: Node3D = enemy_data.get("node")
        if not is_instance_valid(node):
            enemy_data["dead"] = true
            _enemies[i] = enemy_data
            continue
        var objective_position := _player.position
        if _selected_mode_key == "caravan":
            objective_position = Vector3(0.0, 0.0, -4.8)
        var to_player := objective_position - node.position
        to_player.y = 0.0
        var distance := to_player.length()
        if distance > 1.7:
            var move_speed := 1.25 + minf(float(_wave) * 0.06, 0.8)
            if bool(enemy_data.get("boss", false)):
                move_speed *= 0.72
            if _selected_mode_key == "hide_seek":
                move_speed *= 0.72
            _animate_warrior(node, true, _animation_clock + float(i) * 0.6)
            node.position += to_player.normalized() * move_speed * delta
            if to_player.length() > 0.01:
                node.rotation.y = atan2(-to_player.x, -to_player.z)
        else:
            _animate_warrior(node, false, _animation_clock + float(i) * 0.6)
        enemy_data["cooldown"] = float(enemy_data.get("cooldown", 0.5)) - delta
        if distance < 1.85 and float(enemy_data["cooldown"]) <= 0.0 and _enemy_hit_cooldown <= 0.0:
            var damage := 5 + int(_wave / 3)
            if bool(enemy_data.get("boss", false)):
                damage += 7
            if _selected_mode_key == "caravan":
                _caravan_health -= float(damage + 7)
                _set_combat_message("Kervan saldırı aldı! Dayanıklılık: %d/100" % int(maxf(0.0, _caravan_health)))
            else:
                var char_defense := int(_current_character().get("defense", 0)) + int(_save_data.get("defense_bonus", 0)) + int(_save_data.get("armor_level", 0)) * 2
                _combat_health -= maxf(2.0, float(damage - int(char_defense / 3)))
            enemy_data["cooldown"] = 1.0 if not bool(enemy_data.get("boss", false)) else 1.3
            _enemy_hit_cooldown = 0.22
            AudioManager.play_muted_impact()
        _enemies[i] = enemy_data

    _remove_dead_enemies()
    if _combat_health <= 0.0:
        _finish_combat(false, "Savaşçı düştü. Ekipmanlarını yükseltip tekrar dene.")
        return
    if _selected_mode_key == "caravan" and _caravan_health <= 0.0:
        _finish_combat(false, "Kervan yok edildi. Düşmanların ulaşmasını önlemek için onları daha erken alt et.")
        return

    if _selected_mode_key == "hill":
        if _player.position.length() < 3.5:
            _hill_progress += delta
        else:
            _hill_progress = maxf(0.0, _hill_progress - delta * 0.2)
        if _hill_progress >= 35.0:
            _finish_combat(true, "Tepe kontrol altında tutuldu!")
            return
    elif _selected_mode_key == "bear" or _selected_mode_key == "hide_seek":
        _mode_time_left -= delta
        if _mode_time_left <= 0.0:
            _finish_combat(true, "Süre doldu; hayatta kaldın!")
            return
    elif _selected_mode_key == "hot_potato":
        _mode_time_left -= delta
        if _mode_time_left <= 0.0:
            if _potato_holder == "player":
                _combat_health -= 22.0
                _set_combat_message("Sıcak patates sende patladı! Düşmana vurarak patatesi devret.")
                _potato_holder = "player"
            else:
                var potato_target := -1
                for j in range(_enemies.size()):
                    if bool(_enemies[j].get("has_potato", false)):
                        potato_target = j
                        break
                if potato_target >= 0:
                    var potato_enemy: Dictionary = _enemies[potato_target]
                    potato_enemy["hp"] = float(potato_enemy.get("hp", 0.0)) - 180.0
                    if float(potato_enemy["hp"]) <= 0.0:
                        var potato_node: Node3D = potato_enemy.get("node")
                        if is_instance_valid(potato_node):
                            potato_node.queue_free()
                        _enemies.remove_at(potato_target)
                        _save_data["total_kills"] = int(_save_data.get("total_kills", 0)) + 1
                        _save_data["gold"] = int(_save_data.get("gold", 0)) + 35
                        _set_combat_message("SICAK PATATES! Düşman patladı; +35 altın.")
                    else:
                        potato_enemy["has_potato"] = false
                        _enemies[potato_target] = potato_enemy
                        _set_combat_message("Patates patladı ve düşmanı yaraladı!")
                _potato_holder = "player"
            _mode_time_left = 8.0
            if _combat_health <= 0.0:
                _finish_combat(false, "Sıcak patates patlaması seni yendi.")
                return
    if _wave_transition_pending:
        _wave_delay -= delta
        if _wave_delay <= 0.0:
            if _should_finish_after_wave():
                _finish_combat(true, _success_text())
                return
            _spawn_wave()
    elif _enemies.is_empty():
        _wave_transition_pending = true
        _wave_delay = 1.2
    _hud_tick -= delta
    if _hud_tick <= 0.0:
        _hud_tick = 0.22
        _refresh_combat_hud()
    var desired_camera := _player.position + Vector3(0.0, 5.6, 10.5)
    _camera.position = _camera.position.lerp(desired_camera, clampf(delta * 4.0, 0.0, 1.0))
    _camera.look_at(_player.position + Vector3(0.0, 1.0, -1.6), Vector3.UP)


func _animate_warrior(warrior: Node3D, walking: bool, clock: float) -> void:
    if not is_instance_valid(warrior):
        return
    var stride := sin(clock * 8.0) * 0.42 if walking else 0.0
    var left_leg := warrior.get_node_or_null("LeftLeg") as Node3D
    var right_leg := warrior.get_node_or_null("RightLeg") as Node3D
    var left_arm := warrior.get_node_or_null("LeftArm") as Node3D
    var right_arm := warrior.get_node_or_null("RightArm") as Node3D
    if is_instance_valid(left_leg):
        left_leg.rotation.x = stride
    if is_instance_valid(right_leg):
        right_leg.rotation.x = -stride
    if is_instance_valid(left_arm):
        left_arm.rotation.x = -stride * 0.55
    if is_instance_valid(right_arm):
        if warrior == _player and _attack_swing_time > 0.0:
            var swing_progress := 1.0 - _attack_swing_time / 0.24
            right_arm.rotation.x = sin(swing_progress * PI) * 1.3 - 0.12
        else:
            right_arm.rotation.x = stride * 0.55

func _is_bound_pressed(action: String, fallback: int) -> bool:
    var binds: Dictionary = _save_data.get("keybinds", {})
    return Input.is_key_pressed(int(binds.get(action, fallback)))

func _remove_dead_enemies() -> void:
    var survivors: Array[Dictionary] = []
    for enemy_data in _enemies:
        if bool(enemy_data.get("dead", false)):
            continue
        var node: Node3D = enemy_data.get("node")
        if is_instance_valid(node):
            survivors.append(enemy_data)
    _enemies = survivors

func _perform_attack() -> void:
    if _screen_mode != "combat" or _combat_ended or _attack_cooldown > 0.0:
        return
    _attack_cooldown = 0.48
    _attack_swing_time = 0.24
    AudioManager.play_muted_impact()
    if _enemies.is_empty():
        _set_combat_message("Yeni düşman dalgası geliyor...")
        return
    var target_index := -1
    var nearest := 4.2
    for i in range(_enemies.size()):
        var enemy_data: Dictionary = _enemies[i]
        var node: Node3D = enemy_data.get("node")
        if not is_instance_valid(node):
            continue
        var distance := Vector2(node.position.x - _player.position.x, node.position.z - _player.position.z).length()
        if distance <= nearest:
            nearest = distance
            target_index = i
    if target_index < 0:
        _set_combat_message("Saldırı boşa gitti; 4 metreye kadar yaklaş.")
        return
    var target: Dictionary = _enemies[target_index]
    var character := _current_character()
    var damage := int(character.get("attack", 7)) + int(_save_data.get("damage_bonus", 0)) + int(_save_data.get("sword_level", 0)) * 5
    damage = int(round(float(damage) * _difficulty_multiplier()))
    target["hp"] = float(target.get("hp", 30.0)) - float(damage)
    var node: Node3D = target.get("node")
    var hp_label: Label3D = target.get("hp_label")
    if is_instance_valid(hp_label):
        hp_label.text = "CAN %d / %d" % [maxi(0, int(target["hp"])), int(target.get("max_hp", 0))]
        hp_label.modulate = Color(1.0, 0.28, 0.20) if float(target["hp"]) <= float(target.get("max_hp", 1.0)) * 0.35 else Color(1.0, 0.72, 0.42)
    if float(target["hp"]) <= 0.0:
        if is_instance_valid(node):
            node.queue_free()
        _enemies.remove_at(target_index)
        _kills_this_run += 1
        _save_data["total_kills"] = int(_save_data.get("total_kills", 0)) + 1
        _save_data["gold"] = int(_save_data.get("gold", 0)) + (18 if not bool(target.get("boss", false)) else 110)
        if bool(target.get("boss", false)):
            var stats: Dictionary = _save_data.get("mode_stats", {})
            stats["bosses_defeated"] = int(stats.get("bosses_defeated", 0)) + 1
            _save_data["mode_stats"] = stats
        _save_game()
        _set_combat_message("DÜŞMAN YENİLDİ! +%d altın • %d hasar" % [18 if not bool(target.get("boss", false)) else 110, damage])
    else:
        _enemies[target_index] = target
        _set_combat_message("VURUŞ! %d HASAR • DÜŞMAN CANI: %d/%d" % [damage, int(maxf(0.0, float(target["hp"]))), int(target.get("max_hp", 0))])
    if _selected_mode_key == "hot_potato":
        var attacked_node: Node3D = target.get("node")
        var target_alive := false
        for enemy_index in range(_enemies.size()):
            var enemy_state: Dictionary = _enemies[enemy_index]
            var is_target := is_instance_valid(attacked_node) and enemy_state.get("node") == attacked_node
            if _potato_holder == "player":
                enemy_state["has_potato"] = is_target
                if is_target:
                    target_alive = true
            else:
                enemy_state["has_potato"] = false
            _enemies[enemy_index] = enemy_state
        if _potato_holder == "enemy":
            _potato_holder = "player"
            _set_combat_message(_combat_hud_message + " • Sıcak patatesi geri aldın!")
        else:
            _potato_holder = "enemy" if target_alive else "player"
            _set_combat_message(_combat_hud_message + (" • Patates düşmana geçti!" if target_alive else " • Patates sende kaldı!"))
        _mode_time_left = 8.0
    _refresh_combat_hud()

func _use_potion() -> void:
    if _screen_mode != "combat" or _combat_ended:
        return
    if int(_save_data.get("full_potions", 0)) > 0:
        _save_data["full_potions"] = int(_save_data.get("full_potions", 0)) - 1
        _combat_health = _combat_max_health
        _save_game()
    elif int(_save_data.get("potions", 0)) > 0:
        _save_data["potions"] = int(_save_data.get("potions", 0)) - 1
        _combat_health = minf(_combat_max_health, _combat_health + _combat_max_health * 0.45)
        _save_game()
    else:
        _set_combat_message("İksir yok. Mağazadan alabilirsin.")
    _refresh_combat_hud()

func _should_finish_after_wave() -> bool:
    match _selected_mode_key:
        "classic": return _wave >= int(_save_data.get("classic_round_limit", 30))
        "caravan": return _wave >= 5
        "castle": return _wave >= 8
        "boss", "storm": return _wave >= 1
        "bear", "hide_seek", "hill": return false
        "hot_potato": return _wave >= 5
        _: return false

func _success_text() -> String:
    match _selected_mode_key:
        "classic": return "Klasik tur serisi tamamlandı!"
        "caravan": return "Kervan 5 dalgayı atlattı!"
        "castle": return "Kale kapısı ele geçirildi!"
        "boss": return "Efsanevi boss yenildi!"
        "storm": return "Fırtına düellosu kazanıldı!"
        "hill": return "Tepenin kralı oldun!"
        "bear": return "Ayıdan kurtuldun!"
        "hide_seek": return "Saklambaç mücadelesini tamamladın!"
        _: return "Zafer!"

func _finish_combat(victory: bool, message: String) -> void:
    if _combat_ended:
        return
    _combat_ended = true
    if is_instance_valid(_combat_hud_layer):
        _combat_hud_layer.hide()
    var was_conquest_siege := _conquest_battle_target != ""
    var conquest_target_name := _conquest_battle_target
    var was_sea_battle := _sea_battle_active
    if victory:
        _save_data["total_games"] = int(_save_data.get("total_games", 0)) + 1
        _save_data["gold"] = int(_save_data.get("gold", 0)) + 100 + _wave * 12
        if _selected_mode_key == "classic":
            _save_data["classic_wins"] = int(_save_data.get("classic_wins", 0)) + 1
        if _selected_mode_key == "hill":
            var stats: Dictionary = _save_data.get("mode_stats", {})
            stats["hill_wins"] = int(stats.get("hill_wins", 0)) + 1
            _save_data["mode_stats"] = stats
        if was_conquest_siege and conquest_target_name != "":
            var captured: Array = _save_data.get("captured_cities", [])
            if not captured.has(conquest_target_name):
                captured.append(conquest_target_name)
                _save_data["captured_cities"] = captured
                _save_data["gold"] = int(_save_data.get("gold", 0)) + 125
                _save_data["conquest_morale"] = mini(100, int(_save_data.get("conquest_morale", 80)) + 10)
                var relations: Dictionary = _save_data.get("conquest_relations", {})
                var target_nation := _conquest_nation_for_city(_strategy_selected_index)
                relations[target_nation] = maxi(-100, int(relations.get(target_nation, 0)) - 8)
                _save_data["conquest_relations"] = relations
                message = "%s şehri kuşatmadan sonra fethedildi! +125 ganimet ve +10 ordu morali." % conquest_target_name
        if was_sea_battle:
            var sea_reward: Dictionary = _save_data.get("sea", {})
            sea_reward["pirate_defeats"] = int(sea_reward.get("pirate_defeats", 0)) + 1
            sea_reward["gold"] = int(sea_reward.get("gold", 300)) + 110
            sea_reward["ship_health"] = mini(100, int(sea_reward.get("ship_health", 100)) + 15)
            _save_data["sea"] = sea_reward
            message = "Deniz savaşı kazanıldı! +110 deniz altını; gemi gövdesi onarıldı."
    elif was_conquest_siege:
        _save_data["troops"] = maxi(0, int(_save_data.get("troops", 0)) - 5)
        _save_data["conquest_morale"] = maxi(0, int(_save_data.get("conquest_morale", 80)) - 12)
        message = "Kuşatma başarısız oldu. 5 asker kaybedildi; yeniden toplanıp saldırabilirsin."
    elif was_sea_battle:
        var sea_loss: Dictionary = _save_data.get("sea", {})
        sea_loss["ship_health"] = maxi(1, int(sea_loss.get("ship_health", 100)) - 25)
        _save_data["sea"] = sea_loss
        message = "Deniz savaşı kaybedildi. Gemi ağır hasar aldı; onarıp yeniden dene."
    _conquest_battle_target = ""
    _sea_battle_active = false
    _last_result_text = message
    _save_game()
    _remove_dead_enemies()
    _clear_combat_nodes()
    for warrior in _menu_warriors:
        if is_instance_valid(warrior):
            warrior.show()
    _screen_mode = "menu"
    _set_page("ZAFER" if victory else "YENİLGİ", _current_mode_name(), "%s\n\nBu denemede yenilen düşman: %d\nKlasik zafer: %d\nAltın: %d\n\nKazanımlar otomatik kaydedildi." % [message, _kills_this_run, int(_save_data.get("classic_wins", 0)), int(_save_data.get("gold", 0))])
    if not was_conquest_siege and not was_sea_battle:
        _add_menu_button("AYNI MODU TEKRAR OYNA", _start_combat)
    _add_menu_button("MOD SEÇİMİ", _show_modes)
    _add_menu_button("MAĞAZA / İKSİRLER", _show_shop)
    if was_conquest_siege:
        _add_menu_button("DÜNYA FETHİ HARİTASINA DÖN", _show_world_conquest)
    elif was_sea_battle:
        _add_menu_button("DENİZ FETHİ HARİTASINA DÖN", _show_sea_world)
    _add_menu_button("ANA MENÜ", _show_menu)
    if victory:
        AudioManager.play_menu_ambience()

func _show_pause_menu() -> void:
    if _screen_mode != "combat":
        return
    if is_instance_valid(_combat_hud_layer):
        _combat_hud_layer.hide()
    _screen_mode = "paused"
    _set_page("DURAKLATILDI", _current_mode_name(), "Oyun geçici olarak durdu.")
    _add_menu_button("DEVAM ET", _resume_combat)
    _add_menu_button("MODU YENİDEN BAŞLAT", _start_combat)
    _add_menu_button("ANA MENÜYE DÖN", _return_to_menu)

func _resume_combat() -> void:
    if _combat_ended:
        return
    _screen_mode = "combat"
    _set_page("SAVAŞ", _current_mode_name(), "")
    _clear_menu_buttons()
    _menu_layer.hide()
    if is_instance_valid(_dim_layer):
        _dim_layer.hide()
    if is_instance_valid(_combat_hud_layer):
        _combat_hud_layer.show()
    _refresh_combat_hud()

func _return_to_menu() -> void:
    if is_instance_valid(_combat_hud_layer):
        _combat_hud_layer.hide()
    _clear_combat_nodes()
    _combat_ended = true
    for warrior in _menu_warriors:
        if is_instance_valid(warrior):
            warrior.show()
    _show_menu()

func _set_combat_message(value: String) -> void:
    _combat_hud_message = value
    if is_instance_valid(_combat_status_label):
        _combat_status_label.text = value

func _refresh_combat_hud() -> void:
    if not is_instance_valid(_combat_hud_info) or _screen_mode != "combat":
        return
    var mode_key := _selected_mode_key
    var objective := "Dalga %d • Düşman: %d" % [_wave, _enemies.size()]
    if mode_key == "hill":
        objective = "Tepede kal: %.1f / 35 sn • Düşman: %d" % [_hill_progress, _enemies.size()]
    elif mode_key == "bear" or mode_key == "hide_seek":
        objective = "Hayatta kal: %d sn • Düşman: %d" % [int(maxf(0.0, _mode_time_left)), _enemies.size()]
    elif mode_key == "hot_potato":
        objective = "SICAK PATATES: %s • %d sn • Düşman: %d" % ["SENDE" if _potato_holder == "player" else "DÜŞMANDA", int(maxf(0.0, _mode_time_left)), _enemies.size()]
    elif mode_key == "caravan":
        objective = "Kervan: %d/100 • Dalga %d/5 • Düşman: %d" % [int(maxf(0.0, _caravan_health)), _wave, _enemies.size()]
    _combat_hud_info.text = "%s  •  %s\nCAN %d/%d  •  ALTIN %d  •  İKSİR %d + %d" % [
        _current_mode_name(), objective,
        int(maxf(0.0, _combat_health)), int(_combat_max_health),
        int(_save_data.get("gold", 0)),
        int(_save_data.get("potions", 0)), int(_save_data.get("full_potions", 0))
    ]
    _combat_health_bar.max_value = maxf(1.0, _combat_max_health)
    _combat_health_bar.value = clampf(_combat_health, 0.0, _combat_max_health)
    if is_instance_valid(_combat_status_label):
        _combat_status_label.text = _combat_hud_message

func _difficulty_multiplier() -> float:
    if _difficulty == "KOLAY":
        return 1.20
    if _difficulty == "ZOR":
        return 0.78
    return 1.0

func _current_character() -> Dictionary:
    var index := clampi(int(_save_data.get("selected_character", 0)), 0, _characters.size() - 1)
    return _characters[index]

func _current_mode_name() -> String:
    for mode_data in _modes:
        if str(mode_data.get("key", "")) == _selected_mode_key:
            return str(mode_data.get("name", "Savaş"))
    return "Savaş"

func _current_map_name() -> String:
    var index := clampi(int(_save_data.get("selected_map", 0)), 0, _maps.size() - 1)
    return str(_maps[index].get("name", "Arena"))

func _begin_intro() -> void:
    _screen_mode = "intro"
    _set_arena_visible(true)
    if is_instance_valid(_strategy_layer):
        _strategy_layer.hide()
    _intro_time = 0.0
    _intro_variant = randi_range(0, 5)
    var captions := [
        "SPARTA'NIN SON SAVUNMASI", "KRALLIKLAR ATEŞE YÜRÜYOR", "EGE'NİN ÖTESİNDE FETİH", 
        "KUM VE ÇELİK ÇAĞI", "TAHT İÇİN SON SAVAŞ", "EFSANELER YENİDEN DOĞUYOR"
    ]
    _intro_subtitle.text = captions[_intro_variant]
    _intro_progress.value = 0.0
    _intro_title.modulate.a = 0.0
    _intro_subtitle.modulate.a = 0.0
    _menu_layer.hide()
    _intro_layer.show()
    AudioManager.play_intro_score()

func _finish_intro() -> void:
    if _screen_mode != "intro":
        return
    _intro_seen = true
    _save_preferences()
    _show_menu()
    AudioManager.play_menu_ambience()

func _on_skip_pressed() -> void:
    _finish_intro()

func _on_any_button_pressed() -> void:
    AudioManager.play_ui()

func _quit_game() -> void:
    _save_game()
    get_tree().quit()

func _update_intro_camera() -> void:
    var t := clampf(_intro_time / INTRO_DURATION, 0.0, 1.0)
    var smooth_t := smoothstep(0.0, 1.0, t)
    var angle: float
    var radius: float
    var height: float
    var target := Vector3(0.0, 1.25, 0.0)
    match _intro_variant:
        0: # Geniş plan, sonra arenaya yaklaş
            angle = -1.2 + t * 2.4
            radius = lerpf(29.0, 14.8, smooth_t)
            height = 11.0 - smooth_t * 3.2 + sin(t * TAU) * 0.7
        1: # Alçak, savaşçı hizasında yarım tur
            angle = -2.2 + t * 2.0
            radius = lerpf(19.0, 13.8, smooth_t)
            height = 3.5 + sin(t * PI) * 1.1
            target.y = 1.55
        2: # Yüksekten süzülüş
            angle = 0.4 + t * 2.7
            radius = lerpf(24.0, 16.0, smooth_t)
            height = lerpf(16.0, 5.5, smooth_t)
        3: # Yan geçiş
            angle = -0.2 + t * 1.7
            radius = lerpf(18.0, 22.0, smooth_t)
            height = 6.0 + sin(t * PI * 1.5) * 2.0
        4: # Dramatik yaklaşma ve yükseliş
            angle = 1.8 - t * 1.3
            radius = lerpf(31.0, 12.8, smooth_t)
            height = 4.0 + smooth_t * 5.0
        _: # Daha hızlı, geniş çevresel kamera
            angle = -PI + t * 3.4
            radius = lerpf(22.0, 17.0, smooth_t)
            height = 7.0 + cos(t * TAU) * 2.0
    _camera.position = Vector3(sin(angle) * radius, height, cos(angle) * radius)
    _camera.look_at(target, Vector3.UP)

func _update_menu_camera(delta: float) -> void:
    if not is_instance_valid(_camera):
        return
    var t := float(Time.get_ticks_msec()) / 1000.0
    var desired := Vector3(sin(t * 0.10) * 2.2, 7.2 + sin(t * 0.16) * 0.25, 22.2 + cos(t * 0.08) * 1.0)
    _camera.position = _camera.position.lerp(desired, clampf(delta * 0.4, 0.0, 1.0))
    _camera.look_at(Vector3(0.0, 1.25, 0.0), Vector3.UP)

func _material(color: Color) -> StandardMaterial3D:
    var mat := StandardMaterial3D.new()
    mat.albedo_color = color
    mat.roughness = 0.50
    mat.metallic = 0.20
    return mat

func _add_box(parent: Node3D, object_name: String, dimensions: Vector3, pos: Vector3, color: Color) -> MeshInstance3D:
    var item := MeshInstance3D.new()
    item.name = object_name
    var mesh := BoxMesh.new()
    mesh.size = dimensions
    item.mesh = mesh
    item.position = pos
    item.material_override = _material(color)
    parent.add_child(item)
    return item

func _add_cylinder(parent: Node3D, object_name: String, radius: float, height: float, pos: Vector3, color: Color, segments: int = 24) -> MeshInstance3D:
    var item := MeshInstance3D.new()
    item.name = object_name
    var mesh := CylinderMesh.new()
    mesh.top_radius = radius
    mesh.bottom_radius = radius
    mesh.height = height
    mesh.radial_segments = segments
    item.mesh = mesh
    item.position = pos
    item.material_override = _material(color)
    parent.add_child(item)
    return item

func _add_torus(parent: Node3D, object_name: String, outer_radius: float, inner_radius: float, pos: Vector3, color: Color) -> MeshInstance3D:
    var item := MeshInstance3D.new()
    item.name = object_name
    var mesh := TorusMesh.new()
    mesh.outer_radius = outer_radius
    mesh.inner_radius = inner_radius
    mesh.rings = 40
    mesh.ring_segments = 8
    item.mesh = mesh
    item.position = pos
    item.material_override = _material(color)
    parent.add_child(item)
    return item

func _add_sphere(parent: Node3D, object_name: String, radius: float, pos: Vector3, color: Color, material: StandardMaterial3D = null) -> MeshInstance3D:
    var item := MeshInstance3D.new()
    item.name = object_name
    var mesh := SphereMesh.new()
    mesh.radius = radius
    mesh.height = radius * 2.0
    item.mesh = mesh
    item.position = pos
    item.material_override = material if material != null else _material(color)
    parent.add_child(item)
    return item

func _make_warrior(pos: Vector3, armor_color: Color, crest_color: Color) -> Node3D:
    var warrior := Node3D.new()
    warrior.name = "ProceduralWarrior"
    warrior.position = pos
    add_child(warrior)

    var torso := CapsuleMesh.new()
    torso.radius = 0.38
    torso.height = 1.15
    _add_mesh_part(warrior, "BronzeArmor", torso, Vector3(0.0, 1.22, 0.0), armor_color, Vector3.ZERO, Vector3(1.0, 1.0, 0.75))
    _add_sphere(warrior, "Head", 0.27, Vector3(0.0, 1.98, 0.0), Color(0.62, 0.42, 0.30))

    var helmet := SphereMesh.new()
    helmet.radius = 0.31
    helmet.height = 0.45
    _add_mesh_part(warrior, "Helmet", helmet, Vector3(0.0, 2.13, 0.0), Color(0.50, 0.39, 0.22), Vector3.ZERO, Vector3(1.1, 0.65, 1.0))
    _add_box(warrior, "HelmetNoseGuard", Vector3(0.09, 0.30, 0.12), Vector3(0.0, 1.98, 0.25), Color(0.55, 0.43, 0.24))
    _add_box(warrior, "HelmetCrest", Vector3(0.09, 0.35, 0.48), Vector3(0.0, 2.40, -0.015), crest_color)

    var arm_mesh := CapsuleMesh.new()
    arm_mesh.radius = 0.145
    arm_mesh.height = 0.78
    var left_arm_pivot := Node3D.new()
    left_arm_pivot.name = "LeftArm"
    left_arm_pivot.position = Vector3(-0.48, 1.60, 0.0)
    left_arm_pivot.rotation_degrees.z = -22.0
    warrior.add_child(left_arm_pivot)
    _add_mesh_part(left_arm_pivot, "ArmMesh", arm_mesh, Vector3(0.0, -0.30, 0.0), armor_color.darkened(0.08), Vector3.ZERO, Vector3.ONE)
    var right_arm_pivot := Node3D.new()
    right_arm_pivot.name = "RightArm"
    right_arm_pivot.position = Vector3(0.48, 1.60, 0.0)
    right_arm_pivot.rotation_degrees.z = 22.0
    warrior.add_child(right_arm_pivot)
    _add_mesh_part(right_arm_pivot, "ArmMesh", arm_mesh, Vector3(0.0, -0.30, 0.0), armor_color.darkened(0.08), Vector3.ZERO, Vector3.ONE)
    var leg_mesh := CapsuleMesh.new()
    leg_mesh.radius = 0.145
    leg_mesh.height = 0.78
    var left_leg_pivot := Node3D.new()
    left_leg_pivot.name = "LeftLeg"
    left_leg_pivot.position = Vector3(-0.20, 0.72, 0.0)
    warrior.add_child(left_leg_pivot)
    _add_mesh_part(left_leg_pivot, "LegMesh", leg_mesh, Vector3(0.0, -0.34, 0.0), Color(0.22, 0.20, 0.18), Vector3.ZERO, Vector3.ONE)
    var right_leg_pivot := Node3D.new()
    right_leg_pivot.name = "RightLeg"
    right_leg_pivot.position = Vector3(0.20, 0.72, 0.0)
    warrior.add_child(right_leg_pivot)
    _add_mesh_part(right_leg_pivot, "LegMesh", leg_mesh, Vector3(0.0, -0.34, 0.0), Color(0.22, 0.20, 0.18), Vector3.ZERO, Vector3.ONE)
    _add_box(warrior, "ClothCape", Vector3(0.66, 0.98, 0.13), Vector3(0.0, 1.21, -0.32), crest_color.darkened(0.12))
    _add_box(warrior, "BronzeWaistBand", Vector3(0.72, 0.13, 0.52), Vector3(0.0, 0.83, 0.0), Color(0.55, 0.40, 0.20))
    var shield := _add_cylinder(warrior, "RoundShield", 0.39, 0.105, Vector3(-0.66, 1.13, 0.20), crest_color.darkened(0.12), 16 if _graphics_quality == "DÜŞÜK" else 24)
    shield.rotation_degrees.x = 90.0
    if _graphics_quality != "DÜŞÜK":
        _add_sphere(warrior, "Breastplate", 0.32, Vector3(0.0, 1.30, 0.29), Color(0.73, 0.57, 0.31))
        _add_sphere(warrior, "LeftShoulderGuard", 0.22, Vector3(-0.48, 1.58, 0.0), armor_color.lightened(0.12))
        _add_sphere(warrior, "RightShoulderGuard", 0.22, Vector3(0.48, 1.58, 0.0), armor_color.lightened(0.12))
        _add_torus(warrior, "ShieldRim", 0.37, 0.035, Vector3(-0.66, 1.13, 0.265), Color(0.82, 0.65, 0.27))
        _add_sphere(warrior, "ShieldBoss", 0.085, Vector3(-0.66, 1.13, 0.30), Color(0.91, 0.75, 0.37))
        _add_box(warrior, "LeftGreave", Vector3(0.22, 0.42, 0.12), Vector3(-0.20, 0.34, 0.105), Color(0.63, 0.49, 0.28))
        _add_box(warrior, "RightGreave", Vector3(0.22, 0.42, 0.12), Vector3(0.20, 0.34, 0.105), Color(0.63, 0.49, 0.28))
    _add_box(right_arm_pivot, "SwordBlade", Vector3(0.055, 0.77, 0.075), Vector3(0.11, -0.46, -0.10), Color(0.78, 0.83, 0.86))
    _add_box(right_arm_pivot, "SwordGrip", Vector3(0.12, 0.18, 0.14), Vector3(0.11, -0.87, -0.10), Color(0.24, 0.14, 0.08))
    return warrior

func _add_mesh_part(parent: Node3D, object_name: String, mesh: Mesh, pos: Vector3, color: Color, rot_deg: Vector3, scale_value: Vector3) -> MeshInstance3D:
    var item := MeshInstance3D.new()
    item.name = object_name
    item.mesh = mesh
    item.position = pos
    item.rotation_degrees = rot_deg
    item.scale = scale_value
    item.material_override = _material(color)
    parent.add_child(item)
    return item

func _color_from(parts: Variant, fallback: Color) -> Color:
    if parts is Array and parts.size() >= 3:
        return Color(float(parts[0]), float(parts[1]), float(parts[2]))
    return fallback
