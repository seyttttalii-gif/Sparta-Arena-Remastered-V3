extends Control

signal node_clicked(index: int)

var map_kind: String = "world"
var node_labels: Array = []
var owned_names: Array = []
var visited_indices: Array = []
var current_index: int = 0
var selected_index: int = 0
var world_day: int = 1

func configure_map(kind: String, labels: Array, owned: Array, visited: Array, current: int, selected: int, day: int = 1) -> void:
    map_kind = kind
    node_labels = labels.duplicate()
    owned_names = owned.duplicate()
    visited_indices = visited.duplicate()
    current_index = clampi(current, 0, maxi(node_labels.size() - 1, 0))
    selected_index = clampi(selected, 0, maxi(node_labels.size() - 1, 0))
    world_day = maxi(day, 1)
    queue_redraw()

func _draw() -> void:
    if size.x < 10.0 or size.y < 10.0:
        return
    var sea_mode := map_kind == "sea"
    draw_rect(Rect2(Vector2.ZERO, size), Color(0.015, 0.055, 0.095) if sea_mode else Color(0.025, 0.045, 0.052))
    var grid_color := Color(0.14, 0.34, 0.43, 0.28) if sea_mode else Color(0.29, 0.38, 0.29, 0.22)
    for x in range(0, int(size.x), 52):
        draw_line(Vector2(float(x), 0.0), Vector2(float(x), size.y), grid_color, 1.0)
    for y in range(0, int(size.y), 52):
        draw_line(Vector2(0.0, float(y)), Vector2(size.x, float(y)), grid_color, 1.0)
    if sea_mode:
        _draw_sea_land()
    else:
        _draw_world_land()
    _draw_nodes(sea_mode)
    var font := ThemeDB.fallback_font
    var header_color := Color(0.36, 0.85, 0.93) if sea_mode else Color(0.93, 0.70, 0.29)
    var title := "AÇIK DENİZLER • DENİZ ROTASI" if sea_mode else "KRALLIKLAR • ŞEHİR YOLLARI • ORDU HAREKETİ"
    draw_string(font, Vector2(size.x * 0.045, size.y * 0.075), title, HORIZONTAL_ALIGNMENT_LEFT, size.x * 0.68, 22, header_color)
    draw_string(font, Vector2(size.x * 0.045, size.y * 0.11), "GÜN %d  •  Haritadaki düğümlere tıklayarak hedef seç" % world_day, HORIZONTAL_ALIGNMENT_LEFT, size.x * 0.68, 13, Color(0.78, 0.84, 0.84))
    draw_string(font, Vector2(size.x * 0.045, size.y * 0.94), "SPARTA WORLD  /  STRATEJİ HARİTASI" if not sea_mode else "SPARTA WORLD  /  DENİZ SEFERİ", HORIZONTAL_ALIGNMENT_LEFT, size.x * 0.68, 12, Color(0.60, 0.72, 0.75, 0.8))

func _draw_world_land() -> void:
    var coast := PackedVector2Array([
        _p(0.035, 0.28), _p(0.10, 0.18), _p(0.19, 0.21), _p(0.27, 0.14),
        _p(0.35, 0.18), _p(0.43, 0.13), _p(0.53, 0.21), _p(0.64, 0.19),
        _p(0.69, 0.31), _p(0.65, 0.41), _p(0.68, 0.52), _p(0.58, 0.62),
        _p(0.50, 0.68), _p(0.42, 0.82), _p(0.30, 0.80), _p(0.24, 0.72),
        _p(0.15, 0.74), _p(0.08, 0.62), _p(0.055, 0.49)
    ])
    draw_colored_polygon(coast, Color(0.13, 0.24, 0.17))
    var outline: PackedVector2Array = coast.duplicate()
    outline.append(coast[0])
    draw_polyline(outline, Color(0.65, 0.55, 0.31, 0.9), 3.0, true)
    for i in range(12):
        var p := _node_pos(i)
        # Relief strokes, kept sparse to avoid unnecessary rendering cost.
        if i % 2 == 0:
            draw_line(p + Vector2(-24.0, -20.0), p + Vector2(-5.0, -38.0), Color(0.59, 0.64, 0.47, 0.5), 2.0)
            draw_line(p + Vector2(-5.0, -38.0), p + Vector2(15.0, -19.0), Color(0.59, 0.64, 0.47, 0.5), 2.0)
    draw_circle(_p(0.58, 0.22), 20.0, Color(0.22, 0.32, 0.20, 0.85))
    draw_circle(_p(0.59, 0.22), 10.0, Color(0.28, 0.39, 0.22, 0.8))

func _draw_sea_land() -> void:
    # Stylized sea chart with islands, reefs and a storm belt.
    for i in range(18):
        var y := size.y * (0.18 + float(i) * 0.038)
        draw_arc(Vector2(size.x * 0.34, y), size.x * 0.21, 0.05, PI - 0.05, 48, Color(0.21, 0.48, 0.60, 0.18), 1.0, true)
    for i in range(node_labels.size()):
        var p := _node_pos(i)
        var radius := 43.0 if i % 3 == 0 else 31.0
        draw_circle(p + Vector2(-9.0, 8.0), radius + 7.0, Color(0.025, 0.045, 0.04, 0.7))
        draw_circle(p + Vector2(-6.0, 5.0), radius, Color(0.17, 0.31, 0.20))
        draw_arc(p + Vector2(-6.0, 5.0), radius, 0.0, TAU, 36, Color(0.39, 0.58, 0.34), 2.0, true)
    # A storm ring to indicate risk on the far passage.
    draw_arc(_p(0.47, 0.49), 105.0, 0.2, TAU - 0.2, 48, Color(0.31, 0.67, 0.81, 0.48), 2.0, true)

func _draw_nodes(sea_mode: bool) -> void:
    var font := ThemeDB.fallback_font
    for i in range(node_labels.size()):
        var p := _node_pos(i)
        if i < node_labels.size() - 1:
            var next_p := _node_pos(i + 1)
            draw_line(p, next_p, Color(0.91, 0.72, 0.36, 0.52) if not sea_mode else Color(0.32, 0.81, 0.91, 0.58), 3.0, true)
            draw_line(p + Vector2(0.0, 4.0), next_p + Vector2(0.0, 4.0), Color(0.03, 0.06, 0.06, 0.35), 5.0, true)
        var is_owned := owned_names.has(node_labels[i]) if not sea_mode else false
        var is_visited := visited_indices.has(i) if sea_mode else is_owned
        var node_color := Color(0.97, 0.75, 0.29)
        if sea_mode:
            node_color = Color(0.28, 0.82, 0.93) if is_visited else Color(0.50, 0.66, 0.72)
        elif is_owned:
            node_color = Color(0.29, 0.83, 0.53)
        else:
            node_color = Color(0.90, 0.34, 0.30)
        if i == selected_index:
            draw_circle(p, 19.0, Color(0.96, 0.78, 0.27, 0.22))
            draw_arc(p, 20.0, 0.0, TAU, 36, Color(1.0, 0.87, 0.47), 3.0, true)
        draw_circle(p, 11.5, Color(0.015, 0.03, 0.035, 0.95))
        draw_circle(p, 8.0, node_color)
        draw_arc(p, 8.5, 0.0, TAU, 20, Color(0.94, 0.92, 0.77), 1.0, true)
        var label_text := str(node_labels[i])
        if i == current_index:
            label_text = "◆ " + label_text
            draw_circle(p, 15.0, Color(0.97, 0.78, 0.26, 0.16))
        var label_pos := p + Vector2(14.0, -12.0 if i % 2 == 0 else 20.0)
        draw_string(font, label_pos, label_text, HORIZONTAL_ALIGNMENT_LEFT, 210.0, 14, Color(0.94, 0.94, 0.86))
    if current_index >= 0 and current_index < node_labels.size():
        var p := _node_pos(current_index)
        draw_colored_polygon(PackedVector2Array([p + Vector2(0.0, -30.0), p + Vector2(-9.0, -17.0), p + Vector2(9.0, -17.0)]), Color(1.0, 0.79, 0.28))
        draw_string(font, p + Vector2(15.0, 40.0), "ORDUN" if not sea_mode else "GEMİN", HORIZONTAL_ALIGNMENT_LEFT, 90.0, 12, Color(1.0, 0.82, 0.38))

func _node_pos(index: int) -> Vector2:
    var n := index % 12
    var nx: float
    var ny: float
    if map_kind == "sea":
        match index % 8:
            0:
                nx = 0.09
                ny = 0.53
            1:
                nx = 0.20
                ny = 0.38
            2:
                nx = 0.33
                ny = 0.29
            3:
                nx = 0.45
                ny = 0.47
            4:
                nx = 0.57
                ny = 0.32
            5:
                nx = 0.64
                ny = 0.58
            6:
                nx = 0.48
                ny = 0.73
            _:
                nx = 0.29
                ny = 0.70
    else:
        match n:
            0:
                nx = 0.09
                ny = 0.42
            1:
                nx = 0.17
                ny = 0.30
            2:
                nx = 0.29
                ny = 0.35
            3:
                nx = 0.39
                ny = 0.23
            4:
                nx = 0.52
                ny = 0.30
            5:
                nx = 0.61
                ny = 0.42
            6:
                nx = 0.54
                ny = 0.54
            7:
                nx = 0.42
                ny = 0.51
            8:
                nx = 0.31
                ny = 0.60
            9:
                nx = 0.19
                ny = 0.57
            10:
                nx = 0.14
                ny = 0.69
            _:
                nx = 0.34
                ny = 0.75
    return Vector2(size.x * nx, size.y * ny)

func _gui_input(event: InputEvent) -> void:
    if event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_LEFT:
        var mouse_pos: Vector2 = event.position
        for i in range(node_labels.size()):
            if mouse_pos.distance_to(_node_pos(i)) <= 30.0:
                node_clicked.emit(i)
                accept_event()
                return
