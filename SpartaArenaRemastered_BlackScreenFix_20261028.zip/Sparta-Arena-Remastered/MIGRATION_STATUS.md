# Migration status — Sparta Arena Remastered 0.4.0

## Preserved source
The original `SPARTA_ARENA_V57_ANDROID_READY(3).zip` source archive remains in `legacy_v57/`, with its Python/Pygame source, data and starter save examples. This is a reference/source preservation step, not a complete engine conversion.

## New Godot gameplay in this milestone
- The project is a single-player Godot 4 third-person arena prototype with map, character, mode, shop, potion, achievements, save and settings pages.
- Six randomized 13-second intro camera variants are enabled, with Skip.
- UI now has differentiated accent colors and a credits page identifying `SEYİT ALİ` as founder/game designer.
- Audio, graphics/performance, gameplay, and controls are separate settings pages. Quality can be Low/Medium/High; FPS cap can be 30/60/120. Existing prototype profiles are migrated to Medium once, then the user choice persists. Low quality uses fewer decorative objects and less lighting.
- The world-conquest layer is a clickable 2D strategy chart with 72 catalogued city names across 6 continents, adjacent travel, troops, morale, days, recruitment, governor dialogue, surrender/tribute, nation relation values and 8-wave siege combat/capture.
- The sea-conquest layer is a clickable eight-stop chart with ship purchase/health, supplies, travel cost, salvage, storm/pirate events, fishing bait/rod progression, map fragments and relics. Pirate encounters launch arena combat or can be paid off.
- Mode-specific rules have initial implementations for classic rounds, endless play, boss/storm fights, bear survival, hide-seek survival, hill hold, caravan health, hot potato transfer and castle siege. They require playtesting.

## Not done yet
- Professional rigged organic character meshes/skins, bespoke animations and motion capture. The V57 archive does not contain suitable 3D character assets; current characters are stylized procedural geometry with simple walk cycles.
- Full Bannerlord-scale 3D strategy world, visible moving armies, tactical formation AI, diplomacy AI, city interiors and persistent siege simulation.
- Fully 3D ship handling/sea battles with water physics/cannons, island landfall and a real-time fishing minigame.
- Bespoke 3D geometry/objectives for each of the nine arenas.
- A verified 100% feature-by-feature port of all V57 mechanics, online multiplayer, and automated gameplay QA.

## Validation
The source ZIP and catalog JSON files should be checked and the exact Godot version in GitHub Actions should run import, headless launch test and Windows export. Godot is not installed in the current editing environment, so this status intentionally does not claim local runtime/parser success.
