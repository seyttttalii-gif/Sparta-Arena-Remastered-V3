# Sparta Arena Remastered — Full Upgrade 0.4.0

## Bu pakette geliştirilenler

- V57'nin kaynak arşivi ve 2D Python kaynakları `legacy_v57/` altında korunur; özgün dosyalar silinmemiştir.
- Dünya Fethi artık tıklanabilir şehir düğümleri, komşu şehre ordu yürüyüşü, asker/moral/gün/altın yönetimi, vali diyaloğu, altı devlet için ilişki değerleri, haraç, teslim talebi ve sekiz dalgalı şehir kuşatması içerir. Kıtalar şehirlerin en az yarısı ele geçirilince açılır.
- Deniz Fethi artık tıklanabilir sekiz rota, gemi sağlığı, erzak, fırtına ve korsan karşılaşmaları, balık yemi seçimi, olta yükseltmesi, enkaz ganimeti ve harita kalıntısı ilerlemesi içerir. Korsan ve fırtına karşılaşmaları 3D arena savaşı başlatabilir.
- 10 modun ortak savaş döngüsüne ek olarak kervan dayanıklılığı, tepe kontrol süresi, hayatta kalma, boss/kuşatma ve sıcak patates aktarma mantığı özelleştirilmiştir.
- Ana menü renk vurguları güçlendirildi. Yapımcılar sayfasında `SEYİT ALİ` kurucu/oyun tasarımcısı olarak gösterilir.
- Ses, grafik/performance, oynanış ve kontroller ayrı sayfalardadır. İlk açılışta grafik kalitesi ORTA olarak ayarlanır (önceki prototip kaydı bir kez yükseltilir); 30/60/120 FPS seçimi kaydedilir; düşük ayar daha az arena dekoru/daha az düşman ve daha az ışık efekti kullanır.
- Açılış 13 saniye sürer; her çalıştırmada 6 kamera/başlık varyantından biri rastgele seçilir ve Atla düğmesi bulunur.
- Prosedürel savaşçılara basit yürüme döngüsü eklendi, bazı gereksiz mesh ayrıntıları düşük kalite ayarında kaldırılır.

## Bilinmesi gereken önemli sınırlar

Bu, büyük bir remaster için genişletilmiş oynanabilir ara sürümdür; bitmiş Bannerlord ölçeğinde oyun değildir. V57 arşivinde hazır, organik/rigli 3D savaşçı modelleri ya da animasyon rigleri yok. Bu nedenle karakterler daha detaylı renkli düşük-poligon prosedürel modeller ve basit hareket animasyonlarıdır; profesyonel organik 3D karakterler için ayrıca lisanslı/özgün model, iskelet ve animasyon varlıkları gerekir.

Dünya Fethi gerçek zamanlı büyük 3D kıta/ordu haritası yerine oynanabilir bir 2D strateji çizelgesi olarak, Deniz Fethi ise gerçek fizik tabanlı 3D gemi sürüşü yerine rota haritası, ekonomi ve karşılaşmalar olarak uygulanmıştır. Tam 3D ordu formasyonları, diplomatik AI, şehir içi ve gerçek gemi fiziği henüz bitmemiştir. Orijinal kaynakların `legacy_v57/` altında bulunması, her satırın yeni oyuna taşındığı anlamına gelmez.

## Test durumu

Bu ortamda Godot çalıştırılabilir dosyası bulunmadığı için GDScript çalışma zamanı testi yapılamadı. Bu ZIP'in bütünlüğü, JSON dosyaları ve proje kaynaklarının yapısı kontrol edilmelidir; ardından GitHub Actions derlemesi ve oyunun kendisi test edilmelidir. Bir Windows EXE başarıyla oluşturulması, bütün oyun mekaniklerinin hatasız olduğunu tek başına kanıtlamaz.


## 0.4.1 — Savaş arayüzü ve vuruş geri bildirimi
- Savaş sırasında ekranın büyük bölümünü kaplayan menü paneli gizlenir; yerine küçük can/durum HUD'u ve sağ üstte kompakt saldırı/iksir/duraklat düğmeleri kullanılır.
- Düşmanların üstünde mevcut canı gösteren etiket bulunur; her başarılı vuruş etikette görünür.
- Yakın dövüş hedefleme menzili 3.2'den 4.2 oyun birimine çıkarıldı; hasar mesajları küçük HUD'da görünür.
- Arena ışığı ve malzeme roughness/metallic ayarları hafifçe iyileştirildi. Bu, tam sanatsal yeniden modelleme değildir; karakterler hâlâ prosedürel 3D parçalardan oluşur.
- Godot çalışma zamanı bu ortamda mevcut olmadığı için GDScript çalışma testi yapılmadı; paket yalnızca statik inceleme ve ZIP bütünlüğü açısından denetlenmelidir. GitHub Actions sonucu gerçek motor doğrulaması olarak kullanılmalıdır.


## 0.4.2 — Siyah ekran / açılış yükleme düzeltmesi
- Ses dosyaları artık `preload()` ile betik derlenirken değil, AudioManager açılırken `load()` ile yüklenir. Bu, temiz bir çalışma ortamında WAV içe aktarma metaverisi daha oluşmadan autoload derlenmesi sırasında görülebilen yükleme hatasını önlemeyi amaçlar.
- Ses kaynakları eksik/yüklenemezse oyun başlatma akışı durmaz; yalnızca ilgili ses sessiz kalır.
- Ana açılış adımlarına log mesajları eklendi; sonraki hata ayıklamada hangi aşamaya geldiği görülebilir.
- Bu ortamda Godot arayüzünü çalıştırarak görsel test yapılamadı; GitHub Actions yeniden derlemesinden sonra Windows'ta açılış doğrulanmalıdır.
